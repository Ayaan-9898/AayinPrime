import React from 'react';
import { Router, Route, Switch } from 'wouter';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';
import { AuthProvider } from './hooks/use-auth';
import { ProtectedRoute } from "@/lib/protected-route";
import Dashboard from './pages/dashboard';
import AuthPage from './pages/auth-page';
import PatientDashboard from './pages/patient-dashboard';
import HospitalDashboard from './pages/hospital-dashboard';
import Medications from './pages/medications';
import ImplantVerification from './pages/implant-verification';
import ScanMedication from './pages/scan-medication';
import CreateImplant from './pages/create-implant';
import IssueImplant from './pages/issue-implant';
import EditPatient from './pages/edit-patient';
import ScheduleAppointment from './pages/schedule-appointment';
import HospitalAppointments from './pages/hospital-appointments';
import NotFound from './pages/not-found';
import { Toaster } from './components/ui/toaster';
export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-background">
          <Router>
            <Switch>
              <Route path="/auth" component={AuthPage} />
              <ProtectedRoute path="/" component={Dashboard} />
              <ProtectedRoute path="/dashboard" component={Dashboard} />
              <ProtectedRoute path="/patient-dashboard" component={PatientDashboard} />
              <ProtectedRoute path="/hospital-dashboard" component={HospitalDashboard} />
              <ProtectedRoute path="/medications" component={Medications} />
              <ProtectedRoute path="/implant-verification" component={ImplantVerification} />
              <ProtectedRoute path="/scan-medication" component={ScanMedication} />
              <ProtectedRoute path="/dashboard/create-implant" component={CreateImplant} />
              <ProtectedRoute path="/issue-implant" component={IssueImplant} />
              <ProtectedRoute path="/edit-patient" component={EditPatient} />
              <ProtectedRoute path="/schedule-appointment" component={ScheduleAppointment} />
              <ProtectedRoute path="/hospital-appointments" component={HospitalAppointments} />
              <Route component={NotFound} />
            </Switch>
          </Router>
          <Toaster />
        </div>
      </AuthProvider>
    </QueryClientProvider>
  );
}