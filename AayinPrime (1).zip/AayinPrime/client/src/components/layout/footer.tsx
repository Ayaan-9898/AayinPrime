
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="fixed bottom-4 w-full flex justify-between items-center px-6">
      <div className="text-sm text-gray-600">
        Made by Jai Saxena & Gaurav Saxena |{" "}
        <a 
          href="https://inlifeindia.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          Visit our website
        </a>
      </div>
      <div className="text-sm text-green-600 font-medium">
        Crash Prevention Activated
      </div>
    </footer>
  );
};

export default Footer;
