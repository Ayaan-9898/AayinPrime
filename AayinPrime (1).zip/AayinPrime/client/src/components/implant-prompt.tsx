import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Shield, AlertCircle } from "lucide-react";

interface ImplantPromptProps {
  onComplete: (hasImplant: boolean) => void;
  onSkip: () => void;
}

const ImplantPrompt: React.FC<ImplantPromptProps> = ({ onComplete, onSkip }) => {
  const [implantNumber, setImplantNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const verifyImplantMutation = useMutation({
    mutationFn: async (implantId: string) => {
      const res = await apiRequest('POST', '/api/verify-implant', { implantId });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Implant Verified",
        description: "Your implant has been successfully verified"
      });
      onComplete(true);
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message || "Unable to verify implant number",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (implantNumber.trim()) {
      setIsSubmitting(true);
      verifyImplantMutation.mutate(implantNumber.trim());
    }
  };

  const handleSkip = () => {
    onComplete(false);
    onSkip();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Shield className="h-12 w-12 text-primary" />
          </div>
          <CardTitle>Implant Verification</CardTitle>
          <CardDescription>
            Please enter your implant verification number for enhanced security
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                type="text"
                placeholder="Enter implant number"
                value={implantNumber}
                onChange={(e) => setImplantNumber(e.target.value)}
                className="w-full"
                disabled={isSubmitting || verifyImplantMutation.isPending}
              />
            </div>
            
            <div className="flex flex-col space-y-2">
              <Button 
                type="submit" 
                className="w-full"
                disabled={!implantNumber.trim() || isSubmitting || verifyImplantMutation.isPending}
              >
                {(isSubmitting || verifyImplantMutation.isPending) ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  'Verify Implant'
                )}
              </Button>
              
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleSkip}
                disabled={isSubmitting || verifyImplantMutation.isPending}
                className="w-full"
              >
                Skip for Now
              </Button>
            </div>
            
            <div className="flex items-start space-x-2 text-sm text-muted-foreground">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <p>
                Implant verification enhances your account security and enables advanced features. 
                You can verify later in settings.
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ImplantPrompt;