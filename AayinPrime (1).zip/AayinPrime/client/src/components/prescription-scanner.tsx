import React, { useState, useRef, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Camera, CheckCircle, XCircle, Scan } from "lucide-react";
import { Medication } from '@shared/schema';

interface PrescriptionScannerProps {
  onMedicationScanned?: (medication: Medication) => void;
}

const PrescriptionScanner: React.FC<PrescriptionScannerProps> = ({ onMedicationScanned }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<'success' | 'error' | null>(null);
  const [scannedMedication, setScannedMedication] = useState<Medication | null>(null);
  const [manualEntry, setManualEntry] = useState(false);
  const [medicationName, setMedicationName] = useState('');
  const [medicationDosage, setMedicationDosage] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Cleanup camera when component unmounts
  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, []);

  // Mutation to save medication from prescription scan
  const saveMedicationMutation = useMutation({
    mutationFn: async (medicationData: any) => {
      const res = await apiRequest('POST', '/api/medications', {
        ...medicationData,
        source: 'prescription'
      });
      return await res.json();
    },
    onSuccess: (medication: Medication) => {
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
      setScanResult('success');
      setScannedMedication(medication);
      
      toast({
        title: "Medication Added",
        description: `${medication.name} has been added to your medications`,
      });

      if (onMedicationScanned) {
        onMedicationScanned(medication);
      }
    },
    onError: (error: Error) => {
      setScanResult('error');
      toast({
        title: "Scan Failed",
        description: error.message || "Unable to add medication from scan",
        variant: "destructive"
      });
    },
  });

  const startCamera = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported on this device');
      }

      if (videoRef.current) {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
        
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setCameraActive(true);
          
          toast({
            title: "Camera Active",
            description: "Position prescription clearly in view and tap capture"
          });
        };
      }
    } catch (error: any) {
      console.error("Camera error:", error);
      
      let errorMessage = "Unable to access camera";
      if (error.name === 'NotAllowedError') {
        errorMessage = "Camera permission denied. Please allow camera access and try again.";
      } else if (error.name === 'NotFoundError') {
        errorMessage = "No camera found on this device";
      } else if (error.name === 'NotSupportedError') {
        errorMessage = "Camera not supported on this device";
      }
      
      toast({
        title: "Camera Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCameraActive(false);
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        // Set canvas dimensions to match video
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Draw current video frame to canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert canvas to image data URL
        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        
        // Process the image
        processPrescriptionImage(imageData);
      }
    }
  };

  const processPrescriptionImage = async (imageData: string) => {
    try {
      setScanning(true);
      
      // This would typically call an API to process the image
      const response = await apiRequest('POST', '/api/prescription/scan', {
        image: imageData.split(',')[1] // Remove the data URL prefix
      });
      
      const result = await response.json();
      
      if (result && result.medication) {
        saveMedicationMutation.mutate(result.medication);
      } else {
        throw new Error("Could not extract medication information from image");
      }
    } catch (error) {
      setScanResult('error');
      toast({
        title: "Processing Error",
        description: "Could not extract medication information. Try manual entry or a clearer image.",
        variant: "destructive"
      });
      setManualEntry(true);
    } finally {
      setScanning(false);
      stopCamera();
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (medicationName) {
      saveMedicationMutation.mutate({
        name: medicationName,
        dosage: medicationDosage,
      });
    } else {
      toast({
        title: "Missing Information",
        description: "Please enter a medication name",
        variant: "destructive"
      });
    }
  };

  const resetScanner = () => {
    setScanResult(null);
    setScannedMedication(null);
    setManualEntry(false);
    setMedicationName('');
    setMedicationDosage('');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" /> Prescription Scanner
        </CardTitle>
        <CardDescription>
          Scan your prescription label to add medication to your list
        </CardDescription>
      </CardHeader>
      <CardContent>
        {cameraActive ? (
          <div className="relative overflow-hidden rounded-lg">
            <video 
              ref={videoRef} 
              className="w-full object-cover"
              autoPlay 
              playsInline
            />
            {scanning && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <Loader2 className="h-10 w-10 animate-spin text-white" />
              </div>
            )}
          </div>
        ) : manualEntry ? (
          <form onSubmit={handleManualSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Medication Name</label>
              <Input
                value={medicationName}
                onChange={(e) => setMedicationName(e.target.value)}
                placeholder="Enter medication name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Dosage (optional)</label>
              <Input
                value={medicationDosage}
                onChange={(e) => setMedicationDosage(e.target.value)}
                placeholder="e.g. 10mg, 1 tablet"
              />
            </div>
          </form>
        ) : scanResult === 'success' ? (
          <div className="text-center py-6">
            <CheckCircle className="h-16 w-16 mx-auto text-green-500" />
            <p className="mt-4 font-medium">Medication scanned successfully!</p>
            {scannedMedication && (
              <div className="mt-4 p-4 border rounded-lg bg-background">
                <p className="font-medium text-lg">{scannedMedication.name}</p>
                <p className="text-sm text-muted-foreground">Dosage: {scannedMedication.dosage || 'Not specified'}</p>
                <p className="text-sm text-muted-foreground">Schedule: {scannedMedication.frequency} - {scannedMedication.time}</p>
              </div>
            )}
          </div>
        ) : scanResult === 'error' ? (
          <div className="text-center py-6">
            <XCircle className="h-16 w-16 mx-auto text-destructive" />
            <p className="mt-4 text-muted-foreground">Failed to scan medication</p>
          </div>
        ) : (
          <div className="text-center py-8">
            <Camera className="h-16 w-16 mx-auto text-primary opacity-80" />
            <p className="mt-4 text-muted-foreground mb-2">Take a photo of your prescription label to add it to your medications</p>
            <p className="text-xs text-muted-foreground">Position the label clearly in the frame for best results</p>
          </div>
        )}

        {/* Hidden canvas for image capture */}
        <canvas ref={canvasRef} className="hidden" />
      </CardContent>
      <CardFooter className="flex justify-center gap-3">
        {cameraActive ? (
          <>
            <Button onClick={captureImage} className="bg-primary hover:bg-primary/90">
              <Scan className="mr-2 h-4 w-4" /> Capture
            </Button>
            <Button onClick={stopCamera} variant="outline">
              Cancel
            </Button>
          </>
        ) : manualEntry ? (
          <>
            <Button onClick={handleManualSubmit} className="bg-primary hover:bg-primary/90">
              Save Medication
            </Button>
            <Button onClick={resetScanner} variant="outline">
              Cancel
            </Button>
          </>
        ) : scanResult ? (
          <Button onClick={resetScanner} variant="outline">
            Scan Another Prescription
          </Button>
        ) : (
          <>
            <Button onClick={startCamera} className="bg-primary hover:bg-primary/90">
              <Camera className="mr-2 h-4 w-4" /> Start Camera
            </Button>
            <Button onClick={() => setManualEntry(true)} variant="outline">
              Manual Entry
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  );
};

export default PrescriptionScanner;