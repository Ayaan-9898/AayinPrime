
import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Medication } from '@shared/schema';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Scan, CheckCircle, XCircle, Tablet } from "lucide-react";

interface MedicationScannerProps {
  onMedicationScanned?: (medication: Medication) => void;
  mode?: 'hospital' | 'patient';
}

const MedicationScanner: React.FC<MedicationScannerProps> = ({ onMedicationScanned, mode = 'patient' }) => {
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<'success' | 'error' | null>(null);
  const [scannedMedication, setScannedMedication] = useState<Medication | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveMedicationMutation = useMutation({
    mutationFn: async (nfcData: any) => {
      const endpoint = mode === 'hospital' ? '/api/hospital/discharge-card' : '/api/medications/nfc-scan';
      const res = await apiRequest('POST', endpoint, nfcData);
      return await res.json();
    },
    onSuccess: (medication: Medication) => {
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
      setScanResult('success');
      setScannedMedication(medication);
      
      toast({
        title: mode === 'hospital' ? "Discharge Card Created" : "Medication Added",
        description: mode === 'hospital' 
          ? "Discharge card has been written successfully" 
          : `${medication.name} has been added to your medications`,
      });

      if (onMedicationScanned) {
        onMedicationScanned(medication);
      }
    },
    onError: (error: Error) => {
      setScanResult('error');
      toast({
        title: "Scan Failed",
        description: error.message || "Unable to process NFC card",
        variant: "destructive"
      });
    },
  });

  const startNFCScan = async () => {
    try {
      setScanning(true);
      setScanResult(null);

      if (!('NDEFReader' in window)) {
        throw new Error("NFC is not supported on this device");
      }

      const ndef = new (window as any).NDEFReader();
      await ndef.scan();
      
      toast({
        title: mode === 'hospital' ? "Writing Discharge Card" : "Reading Discharge Card",
        description: mode === 'hospital' 
          ? "Please hold the NFC card near the device" 
          : "Please tap your discharge card on the device",
      });

      ndef.addEventListener("reading", ({ message, serialNumber }: any) => {
        const decoder = new TextDecoder();
        let medicationData: any = {};

        for (const record of message.records) {
          if (record.recordType === "text") {
            const textData = decoder.decode(record.data);
            try {
              medicationData = JSON.parse(textData);
            } catch (e) {
              medicationData.name = textData;
            }
          }
        }

        if (serialNumber) {
          medicationData.nfcTagId = serialNumber;
        }

        if (medicationData.implantNumber || medicationData.name) {
          saveMedicationMutation.mutate(medicationData);
        } else {
          throw new Error("Invalid discharge card data");
        }
      });

      ndef.addEventListener("error", (error: any) => {
        throw new Error(error.message || "NFC reading error");
      });
      
    } catch (error) {
      setScanResult('error');
      toast({
        title: "NFC Error",
        description: error instanceof Error ? error.message : "Failed to start NFC scan",
        variant: "destructive"
      });
    } finally {
      setScanning(false);
    }
  };

  const resetScanner = () => {
    setScanResult(null);
    setScannedMedication(null);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Scan className="h-5 w-5" /> 
          {mode === 'hospital' ? 'Write Discharge Card' : 'Scan Discharge Card'}
        </CardTitle>
        <CardDescription>
          {mode === 'hospital' 
            ? 'Write patient discharge information to NFC card'
            : 'Scan your discharge card to get your medication schedule'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center py-6">
          {scanning ? (
            <div className="text-center">
              <Loader2 className="h-16 w-16 animate-spin mx-auto text-primary" />
              <p className="mt-4 text-muted-foreground">
                {mode === 'hospital' ? 'Writing to NFC card...' : 'Scanning discharge card...'}
              </p>
            </div>
          ) : scanResult === 'success' ? (
            <div className="text-center">
              <CheckCircle className="h-16 w-16 mx-auto text-green-500" />
              <p className="mt-4 font-medium">
                {mode === 'hospital' ? 'Discharge card written successfully!' : 'Medication loaded successfully!'}
              </p>
              {scannedMedication && (
                <div className="mt-4 p-4 border rounded-lg bg-background">
                  <p className="font-medium text-lg">{scannedMedication.name}</p>
                  <p className="text-sm text-muted-foreground">Dosage: {scannedMedication.dosage}</p>
                  <p className="text-sm text-muted-foreground">Schedule: {scannedMedication.frequency}</p>
                </div>
              )}
            </div>
          ) : scanResult === 'error' ? (
            <div className="text-center">
              <XCircle className="h-16 w-16 mx-auto text-destructive" />
              <p className="mt-4 text-muted-foreground">Failed to process NFC card</p>
            </div>
          ) : (
            <div className="text-center">
              <Tablet className="h-16 w-16 mx-auto text-primary opacity-80" />
              <p className="mt-4 text-muted-foreground">
                {mode === 'hospital' 
                  ? 'Hold the NFC card near your device to write discharge information'
                  : 'Tap your discharge card to load your medication schedule'}
              </p>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        {scanning ? (
          <Button disabled variant="outline">
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {mode === 'hospital' ? 'Writing...' : 'Scanning...'}
          </Button>
        ) : scanResult ? (
          <Button onClick={resetScanner} variant="outline">
            {mode === 'hospital' ? 'Write Another Card' : 'Scan Another Card'}
          </Button>
        ) : (
          <Button onClick={startNFCScan} className="bg-primary hover:bg-primary/90">
            <Scan className="mr-2 h-4 w-4" />
            {mode === 'hospital' ? 'Write Discharge Card' : 'Start NFC Scan'}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default MedicationScanner;
