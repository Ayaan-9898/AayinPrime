
import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";

const NFCVerification: React.FC = () => {
  const [scanning, setScanning] = useState(false);
  const { user } = useAuth();
  const toast = useToast();

  const verifyMutation = useMutation({
    mutationFn: async (nfcData: string) => {
      const res = await fetch('/api/verify-implant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nfcData })
      });
      if (!res.ok) throw new Error('Verification failed');
      return res.json();
    },
    onSuccess: () => {
      toast.toast({
        title: "Verification Successful",
        description: "Your implant has been verified"
      });
    }
  });

  const startNFCScan = async () => {
    setScanning(true);
    try {
      // Check if NFC is supported
      if (!('NDEFReader' in window)) {
        throw new Error('NFC not supported on this device');
      }

      const ndef = new (window as any).NDEFReader();
      
      // Request permission and start scanning
      await ndef.scan();
      
      toast.toast({
        title: "NFC Scanning Active",
        description: "Hold your NFC card near the device"
      });
      
      ndef.addEventListener("reading", ({ message, serialNumber }: any) => {
        console.log('NFC data received:', message, serialNumber);
        
        // Extract the implant verification number from NFC data
        let implantNumber = '';
        if (message && message.records) {
          for (const record of message.records) {
            if (record.recordType === "text") {
              const textDecoder = new TextDecoder(record.encoding);
              implantNumber = textDecoder.decode(record.data);
              break;
            }
          }
        }
        
        if (!implantNumber && serialNumber) {
          implantNumber = serialNumber;
        }
        
        if (implantNumber) {
          verifyMutation.mutate(implantNumber);
          setScanning(false);
        } else {
          toast.toast({
            title: "NFC Error",
            description: "No valid implant data found on the card",
            variant: "destructive"
          });
          setScanning(false);
        }
      });

      ndef.addEventListener("readingerror", () => {
        toast.toast({
          title: "NFC Read Error",
          description: "Failed to read NFC data. Please try again.",
          variant: "destructive"
        });
        setScanning(false);
      });

    } catch (error: any) {
      console.error('NFC Error:', error);
      
      if (error.name === 'NotAllowedError') {
        toast.toast({
          title: "NFC Permission Denied",
          description: "Please allow NFC access and try again",
          variant: "destructive"
        });
      } else if (error.name === 'NotSupportedError') {
        toast.toast({
          title: "NFC Not Supported",
          description: "Your device does not support NFC scanning",
          variant: "destructive"
        });
      } else {
        toast.toast({
          title: "NFC Error",
          description: "Please ensure NFC is enabled on your device and try again",
          variant: "destructive"
        });
      }
      setScanning(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center">
      <Button 
        className="w-full bg-primary hover:bg-primary/90"
        onClick={startNFCScan}
        disabled={scanning}
      >
        {scanning ? 'Scanning...' : 'Start NFC Scan'}
      </Button>
    </div>
  );
};

export default NFCVerification;
