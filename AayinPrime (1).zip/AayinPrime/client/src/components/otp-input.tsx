import React, { useState, useRef, useEffect, KeyboardEvent, ChangeEvent } from 'react';

interface OTPInputProps {
  length: number;
  value: string;
  onChange: (value: string) => void;
  onComplete?: (value: string) => void;
  autoFocus?: boolean;
}

export default function OTPInput({ 
  length, 
  value, 
  onChange,
  onComplete,
  autoFocus = false
}: OTPInputProps) {
  const [activeInput, setActiveInput] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Initialize inputRefs with the length
  useEffect(() => {
    inputRefs.current = Array(length).fill(null);
  }, [length]);

  // Auto-focus the first input when component mounts
  useEffect(() => {
    if (autoFocus && inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, [autoFocus]);

  // Helper to focus on a specific input
  const focusInput = (index: number) => {
    const selectedIndex = Math.max(Math.min(length - 1, index), 0);
    setActiveInput(selectedIndex);
    inputRefs.current[selectedIndex]?.focus();
  };

  // Focus the next input after filling one
  const focusNextInput = () => {
    focusInput(activeInput + 1);
  };

  // Focus the previous input when backspacing
  const focusPrevInput = () => {
    focusInput(activeInput - 1);
  };

  // Update the value when an input changes
  const handleChange = (e: ChangeEvent<HTMLInputElement>, index: number) => {
    const newValue = e.target.value;
    
    // Validate the input is a single digit
    if (newValue.match(/^[0-9]$/)) {
      // Update the value by inserting the new digit at the correct position
      const newOtpValue = 
        value.substring(0, index) + newValue + value.substring(index + 1);
      
      onChange(newOtpValue);
      
      // Move to next input if available
      if (index < length - 1) {
        focusNextInput();
      } else if (index === length - 1 && onComplete) {
        onComplete(newOtpValue);
      }
    }
  };

  // Handle key presses like backspace, arrow keys
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      
      // If input has value, clear it
      if (value[index]) {
        const newOtpValue = 
          value.substring(0, index) + '' + value.substring(index + 1);
        onChange(newOtpValue);
      } 
      // If input is empty, focus previous input
      else if (index > 0) {
        focusPrevInput();
      }
    } 
    // Arrow navigation
    else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      focusPrevInput();
    } 
    else if (e.key === 'ArrowRight') {
      e.preventDefault();
      focusNextInput();
    }
  };

  // Handle clipboard paste
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    
    const pastedData = e.clipboardData.getData('text/plain').trim();
    
    // Validate pasted data contains only digits
    if (/^[0-9]+$/.test(pastedData)) {
      // Take only the needed length from the pasted data
      const pastedOtp = pastedData.slice(0, length);
      
      // Pad with empty strings if pasted data is shorter than length
      const newOtp = pastedOtp.padEnd(length, '');
      
      onChange(newOtp);
      
      // Check if the paste completed the OTP
      if (pastedOtp.length === length && onComplete) {
        onComplete(pastedOtp);
      }
    }
  };

  return (
    <div className="flex justify-center gap-2">
      {Array.from({ length }, (_, index) => (
        <input
          key={index}
          type="text"
          pattern="[0-9]*"
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={1}
          ref={(input) => (inputRefs.current[index] = input)}
          value={value[index] || ''}
          className={`
            w-12 h-14 text-center text-2xl font-bold
            bg-background border-2 rounded-md
            focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary
            ${
              activeInput === index
                ? 'border-primary'
                : value[index]
                ? 'border-primary/50 bg-primary/5'
                : 'border-border'
            }
            transition-all duration-150
          `}
          onChange={(e) => handleChange(e, index)}
          onKeyDown={(e) => handleKeyDown(e, index)}
          onPaste={index === 0 ? handlePaste : undefined}
          onFocus={() => setActiveInput(index)}
          aria-label={`OTP digit ${index + 1}`}
          disabled={value.length < index} // Only enable if previous inputs are filled
        />
      ))}
    </div>
  );
}