import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import OTPInput from "@/components/otp-input";

interface PinVerificationProps {
  onVerified: () => void;
  onCancel: () => void;
}

export default function PinVerification({ onVerified, onCancel }: PinVerificationProps) {
  const [pin, setPin] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [lockTime, setLockTime] = useState(0);
  const { toast } = useToast();

  // Default hospital PIN - in a real app, this would be set by the hospital admin
  const HOSPITAL_PIN = '1234';
  const MAX_ATTEMPTS = 3;
  const LOCK_TIME = 30; // in seconds

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isLocked && lockTime > 0) {
      interval = setInterval(() => {
        setLockTime(prev => {
          if (prev <= 1) {
            setIsLocked(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLocked, lockTime]);

  const handleVerify = () => {
    setIsSubmitting(true);
    
    // Simulate verification delay
    setTimeout(() => {
      if (pin === HOSPITAL_PIN) {
        toast({
          title: "Verification Successful",
          description: "You are now authorized to edit patient medications",
          variant: "default",
        });
        setAttempts(0);
        onVerified();
      } else {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        
        if (newAttempts >= MAX_ATTEMPTS) {
          setIsLocked(true);
          setLockTime(LOCK_TIME);
          toast({
            title: "Too Many Attempts",
            description: `Account locked for ${LOCK_TIME} seconds. Please try again later.`,
            variant: "destructive",
          });
        } else {
          toast({
            title: "Verification Failed",
            description: `Invalid PIN. ${MAX_ATTEMPTS - newAttempts} attempts remaining.`,
            variant: "destructive",
          });
        }
      }
      
      setIsSubmitting(false);
      setPin('');
    }, 1000);
  };

  return (
    <Card className="w-full max-w-md mx-auto border-primary/20 shadow-lg">
      <CardHeader className="space-y-2 text-center">
        <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="24" 
            height="24" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="text-primary"
          >
            <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
            <path d="M8 12h.01" />
            <path d="M12 12h.01" />
            <path d="M16 12h.01" />
            <path d="M8 16h.01" />
            <path d="M12 16h.01" />
            <path d="M16 16h.01" />
          </svg>
        </div>
        <CardTitle className="text-2xl font-bold">Hospital PIN Verification</CardTitle>
        <CardDescription>
          Enter the 4-digit hospital PIN to access patient medication edits
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="py-4">
          <OTPInput 
            length={4} 
            value={pin} 
            onChange={setPin} 
            autoFocus
            onComplete={isLocked ? undefined : handleVerify}
          />
        </div>
        <div className="text-sm text-center space-y-1">
          {isLocked ? (
            <p className="text-destructive">Account locked. Try again in {lockTime} seconds.</p>
          ) : (
            <p className="text-muted-foreground">This PIN protects patient data and is required before making changes</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-3 pb-6">
        <Button 
          className="w-full" 
          onClick={handleVerify}
          disabled={pin.length !== 4 || isSubmitting || isLocked}
          size="lg"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Verifying...
            </span>
          ) : (
            "Verify & Continue"
          )}
        </Button>
        <Button 
          variant="ghost" 
          className="w-full text-muted-foreground hover:text-foreground" 
          onClick={onCancel}
          disabled={isSubmitting}
        >
          Cancel
        </Button>
      </CardFooter>
    </Card>
  );
}