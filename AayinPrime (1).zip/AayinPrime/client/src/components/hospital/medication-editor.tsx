import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import PinVerification from "./pin-verification";
import { User, Medication } from "@shared/schema";

interface MedicationEditorProps {
  isOpen: boolean;
  onClose: () => void;
  patient: User;
  onMedicationAdded: (medication: Medication) => void;
}

export default function MedicationEditor({ isOpen, onClose, patient, onMedicationAdded }: MedicationEditorProps) {
  const [isVerifying, setIsVerifying] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPatientNotice, setShowPatientNotice] = useState(false);
  const [medicationData, setMedicationData] = useState({
    name: '',
    dosage: '',
    frequency: '',
    time: '',
    instructions: '',
  });
  const { toast } = useToast();

  const handleVerificationComplete = () => {
    setIsVerifying(false);
    setShowPatientNotice(true);
    
    // Simulate sending notification to patient
    setTimeout(() => {
      setShowPatientNotice(false);
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setMedicationData({ ...medicationData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    if (!medicationData.name || !medicationData.dosage || !medicationData.frequency) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields (Name, Dosage, Frequency)",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch(`/api/hospital/patient/${patient.id}/medication`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          implantVerificationNumber: patient.implantVerificationNumber,
          name: medicationData.name,
          dosage: medicationData.dosage,
          frequency: medicationData.frequency,
          time: medicationData.time,
          instructions: medicationData.instructions,
          status: 'active',
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to add medication");
      }

      const medication = await response.json();
      
      toast({
        title: "Medication Added",
        description: `${medicationData.name} has been added to ${patient.name}'s prescriptions.`,
      });
      
      onMedicationAdded(medication);
      
      // Reset form and close
      setMedicationData({
        name: '',
        dosage: '',
        frequency: '',
        time: '',
        instructions: '',
      });
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        {isVerifying ? (
          <PinVerification
            onVerified={handleVerificationComplete}
            onCancel={onClose}
          />
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Edit Patient Medication</DialogTitle>
              <DialogDescription>
                Add or modify medication for {patient.name}
              </DialogDescription>
            </DialogHeader>
            
            {showPatientNotice && (
              <div className="bg-blue-50 border border-blue-200 text-blue-800 p-4 rounded-md mb-4">
                <p className="text-sm font-medium">
                  Patient has been notified. Message: "Please wait while hospital edits your medications. Thanks! 😊"
                </p>
              </div>
            )}
            
            <div className="grid gap-4 py-3">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name*
                </Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="Medication name"
                  className="col-span-3"
                  value={medicationData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="dosage" className="text-right">
                  Dosage*
                </Label>
                <Input
                  id="dosage"
                  name="dosage"
                  placeholder="e.g., 5mg"
                  className="col-span-3"
                  value={medicationData.dosage}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="frequency" className="text-right">
                  Frequency*
                </Label>
                <Input
                  id="frequency"
                  name="frequency"
                  placeholder="e.g., Once daily"
                  className="col-span-3"
                  value={medicationData.frequency}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="time" className="text-right">
                  Time
                </Label>
                <Input
                  id="time"
                  name="time"
                  placeholder="e.g., Morning"
                  className="col-span-3"
                  value={medicationData.time}
                  onChange={handleChange}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="instructions" className="text-right">
                  Instructions
                </Label>
                <Textarea
                  id="instructions"
                  name="instructions"
                  placeholder="Special instructions for patient"
                  className="col-span-3 min-h-[80px]"
                  value={medicationData.instructions}
                  onChange={handleChange}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" /> Saving...
                  </span>
                ) : (
                  "Save Medication"
                )}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}