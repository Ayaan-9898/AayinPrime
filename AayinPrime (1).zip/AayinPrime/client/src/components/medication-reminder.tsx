
import React, { useState } from 'react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const MedicationReminder: React.FC = () => {
  const [isNFCScanning, setIsNFCScanning] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const startNFCScan = async () => {
    setIsNFCScanning(true);
    try {
      const ndef = new (window as any).NDEFReader();
      await ndef.scan();
      
      ndef.addEventListener("reading", async ({ message }: any) => {
        const response = await fetch('/api/medications/nfc-scan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nfcData: message })
        });
        
        if (response.ok) {
          toast({
            title: "Success",
            description: "Medication schedule updated from discharge card"
          });
          queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
        }
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Please ensure NFC is enabled on your device",
        variant: "destructive"
      });
    }
    setIsNFCScanning(false);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (error) {
      toast({
        title: "Camera Error",
        description: "Unable to access camera",
        variant: "destructive"
      });
    }
  };

  const scanPrescription = async () => {
    if (!videoRef.current) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
    
    const imageBlob = await new Promise<Blob>((resolve) => 
      canvas.toBlob((blob) => resolve(blob!), 'image/jpeg')
    );

    const formData = new FormData();
    formData.append('prescription', imageBlob);

    const response = await fetch('/api/medications/scan-prescription', {
      method: 'POST',
      body: formData
    });

    if (response.ok) {
      toast({
        title: "Success",
        description: "Prescription scanned and reminders set"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
    }

    // Stop camera
    const stream = videoRef.current.srcObject as MediaStream;
    stream.getTracks().forEach(track => track.stop());
    setIsCameraActive(false);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="card bg-white p-6 rounded-xl shadow">
        <h3 className="text-lg font-semibold mb-4">NFC Scan</h3>
        <button
          className="w-full btn btn-primary"
          onClick={startNFCScan}
          disabled={isNFCScanning}
        >
          {isNFCScanning ? (
            <>
              <Loader2 className="animate-spin mr-2" />
              Scanning...
            </>
          ) : (
            'Scan NFC Card'
          )}
        </button>
      </div>

      <div className="card bg-white p-6 rounded-xl shadow">
        <h3 className="text-lg font-semibold mb-4">Prescription Scanner</h3>
        {isCameraActive ? (
          <div className="space-y-4">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full rounded-lg"
            />
            <button
              className="w-full btn btn-primary"
              onClick={scanPrescription}
            >
              Capture Prescription
            </button>
          </div>
        ) : (
          <button
            className="w-full btn btn-primary"
            onClick={startCamera}
          >
            Start Camera
          </button>
        )}
      </div>
    </div>
  );
};

export default MedicationReminder;
