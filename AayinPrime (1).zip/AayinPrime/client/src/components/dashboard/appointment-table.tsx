import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Appointment } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Loader2 } from 'lucide-react';

const AppointmentTable: React.FC = () => {
  const { data: appointments, isLoading } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });
  
  // Status badge component
  const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
    const variant = status === 'confirmed'
      ? 'primary'
      : status === 'pending'
        ? 'gray'
        : status === 'cancelled'
          ? 'error'
          : 'default';
    
    return (
      <Badge variant={variant as any} className="capitalize">
        {status}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-display font-semibold text-gray-800">Upcoming Appointments</h2>
        </div>
        <div className="bg-white rounded-2xl p-10 card-shadow flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-display font-semibold text-gray-800">Upcoming Appointments</h2>
        <button className="text-primary text-sm font-medium flex items-center">
          <span>Schedule New</span>
          <span className="material-icons text-sm ml-1">add_circle</span>
        </button>
      </div>
      
      <div className="bg-white rounded-2xl overflow-hidden card-shadow">
        {appointments && appointments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500">Doctor</th>
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500">Specialty</th>
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500">Date & Time</th>
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500">Status</th>
                  <th className="py-4 px-6 text-left text-sm font-medium text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id} className="border-b border-gray-100 hover:bg-gray-50 transition">
                    <td className="py-4 px-6">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full bg-gray-200 mr-3"></div>
                        <div>
                          <p className="font-medium">{appointment.doctorName}</p>
                          <p className="text-xs text-gray-500">{appointment.clinic}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-sm">{appointment.specialty}</td>
                    <td className="py-4 px-6">
                      <p className="font-medium">{format(new Date(appointment.date), 'MMM d, yyyy')}</p>
                      <p className="text-xs text-gray-500">{format(new Date(appointment.date), 'h:mm a')}</p>
                    </td>
                    <td className="py-4 px-6">
                      <StatusBadge status={appointment.status} />
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex space-x-2">
                        <button className="p-1 rounded-lg hover:bg-gray-100 transition">
                          <span className="material-icons text-sm text-gray-600">edit</span>
                        </button>
                        <button className="p-1 rounded-lg hover:bg-gray-100 transition">
                          <span className="material-icons text-sm text-gray-600">videocam</span>
                        </button>
                        <button className="p-1 rounded-lg hover:bg-gray-100 transition">
                          <span className="material-icons text-sm text-gray-600">more_vert</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-16">
            <span className="material-icons text-4xl text-gray-300">event_busy</span>
            <p className="mt-2 text-gray-500">No upcoming appointments</p>
            <button className="mt-4 px-4 py-2 bg-primary/10 text-primary rounded-lg text-sm">
              Schedule an appointment
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default AppointmentTable;
