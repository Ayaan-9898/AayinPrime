import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { HealthMetric } from '@shared/schema';
import { cn } from '@/lib/utils';

// Helper components
interface MetricCardProps {
  title: string;
  value: string;
  unit?: string;
  status: string;
  statusText: string;
  icon: string;
  iconColor: string;
  chartData: number[];
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  unit, 
  status, 
  statusText, 
  icon, 
  iconColor,
  chartData 
}) => {
  const getStatusColor = () => {
    switch(status) {
      case 'normal':
      case 'optimal':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'below_target':
        return 'text-error';
      default:
        return 'text-gray-500';
    }
  };

  const getStatusIcon = () => {
    switch(status) {
      case 'normal':
        return 'trending_up';
      case 'optimal':
        return 'check_circle';
      case 'warning':
        return 'info';
      case 'below_target':
        return 'trending_down';
      default:
        return 'help';
    }
  };

  return (
    <div className="bg-white rounded-2xl p-5 card-shadow hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <h3 className="text-2xl font-semibold mb-1">
            {value} {unit && <span className="text-sm">{unit}</span>}
          </h3>
          <p className={cn("text-xs inline-flex items-center", getStatusColor())}>
            <span className="material-icons text-xs mr-1">{getStatusIcon()}</span>
            <span>{statusText}</span>
          </p>
        </div>
        <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", `bg-${iconColor}/10`)}>
          <span className={cn("material-icons", `text-${iconColor}`)}>{icon}</span>
        </div>
      </div>

      <div className="mt-4 h-12 overflow-hidden">
        <div className="flex justify-between items-end h-full">
          {chartData.map((height, i) => (
            <div 
              key={i} 
              className={cn(
                "w-1 rounded-t-sm", 
                i >= chartData.length - 3 ? `bg-${iconColor}` : `bg-${iconColor}/60`
              )} 
              style={{ height: `${height}%` }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
};

const HealthOverview: React.FC = () => {
  const { data: healthMetrics, isLoading } = useQuery<HealthMetric[]>({
    queryKey: ['/api/health-metrics'],
  });

  // Group metrics by type
  const metricsByType = React.useMemo(() => {
    if (!healthMetrics) return {};

    return healthMetrics.reduce((acc, metric) => {
      if (!acc[metric.type]) {
        acc[metric.type] = [];
      }
      acc[metric.type].push(metric);
      return acc;
    }, {} as Record<string, HealthMetric[]>);
  }, [healthMetrics]);

  // Get the latest metric of each type
  const getLatestMetric = (type: string) => {
    if (!metricsByType[type]) return null;
    return metricsByType[type].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )[0];
  };

  // Generate random chart data for now
  const generateChartData = () => {
    return Array(7).fill(0).map(() => Math.floor(Math.random() * 60) + 30);
  };

  const heartRate = getLatestMetric('heart_rate');
  const bloodPressure = getLatestMetric('blood_pressure');
  const sleep = getLatestMetric('sleep');
  const activity = getLatestMetric('activity');

  if (isLoading) {
    return (
      <section className="mb-8 animate-pulse">
        <div className="h-8 bg-gray-200 rounded-md w-48 mb-6"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="bg-gray-100 rounded-2xl p-5 h-40"></div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-display font-semibold text-gray-800">Health Overview</h2>
        <button className="text-primary text-sm font-medium flex items-center">
          <span>View Full Report</span>
          <span className="material-icons text-sm ml-1">arrow_forward</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Heart Rate"
          value={heartRate?.value || "78"}
          unit="bpm"
          status={heartRate?.status || "normal"}
          statusText="Normal range"
          icon="favorite"
          iconColor="primary"
          chartData={generateChartData()}
        />

        <MetricCard
          title="Blood Pressure"
          value={bloodPressure?.value || "120/80"}
          unit=""
          status={bloodPressure?.status || "optimal"}
          statusText="Optimal"
          icon="speed"
          iconColor="secondary"
          chartData={generateChartData()}
        />

        <MetricCard
          title="Sleep Quality"
          value={sleep?.value || "7.2"}
          unit="hrs"
          status={sleep?.status || "warning"}
          statusText="Could be better"
          icon="nightlight"
          iconColor="accent"
          chartData={generateChartData()}
        />

        <MetricCard
          title="Activity"
          value={activity?.value || "6,543"}
          unit="steps"
          status={activity?.status || "below_target"}
          statusText="Below target"
          icon="directions_walk"
          iconColor="primary"
          chartData={generateChartData()}
        />
      </div>
    </section>
  );
};

export default HealthOverview;