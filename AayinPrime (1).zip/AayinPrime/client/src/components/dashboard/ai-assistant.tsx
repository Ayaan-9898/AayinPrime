import React, { useState, useEffect, useRef } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Conversation } from '@shared/schema';
import { Loader2 } from 'lucide-react';

interface Message {
  role: string;
  content: string;
}

const AIAssistant: React.FC = () => {
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [currentConversationId, setCurrentConversationId] = useState<number | undefined>(undefined);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Get the latest conversation or create a new one
  const { data: conversations, isLoading: isLoadingConversations } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
  });
  
  // Effect to set the current conversation to the latest one
  useEffect(() => {
    if (conversations && conversations.length > 0) {
      // Sort by created date descending and get the most recent
      const sortedConversations = [...conversations].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      setCurrentConversationId(sortedConversations[0].id);
    }
  }, [conversations]);
  
  // Get messages for the current conversation
  const { data: currentConversation, isLoading: isLoadingMessages } = useQuery<Conversation>({
    queryKey: ['/api/conversations', currentConversationId],
    enabled: !!currentConversationId,
  });
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest('POST', '/api/ai/chat', {
        message,
        conversationId: currentConversationId
      });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      if (currentConversationId) {
        queryClient.invalidateQueries({ queryKey: ['/api/conversations', currentConversationId] });
      }
      setCurrentConversationId(data.conversation.id);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentConversation]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    sendMessageMutation.mutate(input);
    setInput('');
  };
  
  const messages = currentConversation?.messages || [];
  const filteredMessages = messages.filter(msg => msg.role !== 'system');
  
  return (
    <div className="bg-white rounded-2xl p-6 card-shadow overflow-hidden relative">
      <div className="absolute -right-10 -top-10 w-32 h-32 rounded-full bg-accent/10"></div>
      <div className="absolute -left-10 -bottom-10 w-24 h-24 rounded-full bg-primary/10"></div>
      
      <h2 className="text-lg font-display font-semibold text-gray-800 mb-4">AI Health Assistant</h2>
      
      <div className="bg-accent/5 rounded-2xl p-4 hover:shadow-md transition-shadow duration-300 mb-4 relative">
        <div className="absolute right-2 top-2 bg-accent/10 text-accent text-xs px-2 py-1 rounded-full">
          AI powered
        </div>
        <h3 className="text-sm font-medium mb-2">Health Insights</h3>
        <p className="text-sm text-gray-600">
          Ask me about your medications, eye health, or general health questions. I'm here to help!
        </p>
      </div>
      
      <div className="h-[200px] overflow-y-auto mb-4 space-y-4 pr-2">
        {isLoadingMessages || isLoadingConversations ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="h-6 w-6 animate-spin text-accent" />
          </div>
        ) : filteredMessages.length > 0 ? (
          filteredMessages.map((message, index) => (
            <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : ''}`}>
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white shrink-0 mr-3">
                  <span className="material-icons text-sm">smart_toy</span>
                </div>
              )}
              
              <div className={cn(
                "p-3 rounded-2xl max-w-[85%]",
                message.role === 'user' 
                  ? "bg-primary/10 rounded-tr-none mr-3" 
                  : "bg-gray-100 rounded-tl-none ml-3"
              )}>
                <p className="text-sm">{message.content}</p>
              </div>
              
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                  <span className="material-icons text-sm text-gray-600">person</span>
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="flex justify-center items-center h-full text-gray-400 text-sm">
            No messages yet. Start a conversation!
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <form onSubmit={handleSendMessage} className="relative">
        <input 
          type="text" 
          className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-300 focus:ring-2 focus:ring-accent focus:border-accent outline-none transition"
          placeholder="Ask your health assistant..."
          value={input}
          onChange={e => setInput(e.target.value)}
          disabled={sendMessageMutation.isPending}
        />
        <button 
          type="submit"
          className="absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center"
          disabled={sendMessageMutation.isPending}
        >
          {sendMessageMutation.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <span className="material-icons text-sm">send</span>
          )}
        </button>
      </form>
    </div>
  );
};

export default AIAssistant;

// Helper function for class names
function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
