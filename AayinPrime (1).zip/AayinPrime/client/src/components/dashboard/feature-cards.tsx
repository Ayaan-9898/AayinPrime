import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { useLocation } from 'wouter';

// NFC Scan Card
const NFCScanCard: React.FC = () => {
  const { toast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [, navigate] = useLocation();
  
  const scanMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/nfc/scan', {});
      return await res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "NFC Scan Complete",
        description: `Medication: ${data.name} - Authentic`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Scan Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setScanning(false);
    }
  });
  
  const handleScan = () => {
    // Navigate to the dedicated scanning page instead of doing a quick scan
    navigate('/scan-medication');
  };

  return (
    <div className="bg-dark text-white rounded-2xl p-6 card-shadow overflow-hidden relative">
      <div className="absolute -right-10 -top-10 w-32 h-32 rounded-full bg-primary/20"></div>
      
      <div className="relative">
        <h2 className="text-lg font-display font-semibold mb-2">NFC Medication Scan</h2>
        <p className="text-sm text-gray-300 mb-6">Quickly scan your medication to verify authenticity and get detailed information.</p>
        
        <div className="bg-white/10 rounded-xl p-4 mb-4 backdrop-blur-sm">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
              <span className="material-icons text-primary">contactless</span>
            </div>
            <div>
              <h3 className="text-sm font-medium">
                {result ? "Scan Complete" : "Ready to Scan"}
              </h3>
              <p className="text-xs text-gray-400">
                {result 
                  ? `${result.name} - ${result.isAuthentic ? 'Authentic' : 'Warning: May not be authentic'}` 
                  : "Hold your phone near the medication"}
              </p>
            </div>
          </div>
          
          {result && (
            <div className="mt-3 pt-3 border-t border-white/10 text-xs text-gray-300">
              <div className="grid grid-cols-2 gap-2">
                <div>Manufacturer: {result.manufacturer}</div>
                <div>Batch: {result.batchNumber}</div>
                <div>Expiry: {result.expiryDate}</div>
                <div>Made: {result.manufactureDate}</div>
              </div>
            </div>
          )}
        </div>
        
        <button 
          className="w-full py-3 px-4 rounded-xl bg-primary/80 hover:bg-primary text-white font-medium transition flex items-center justify-center"
          onClick={handleScan}
        >
          <span className="material-icons mr-2">contactless</span>
          <span>Go to Medication Scanner</span>
        </button>
      </div>
    </div>
  );
};

// Prescription Scanner Card
const PrescriptionScannerCard: React.FC = () => {
  const { toast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [, navigate] = useLocation();
  
  const scanMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/prescription/scan', {});
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Prescription Scanned",
        description: `Found ${data.medications.length} medications`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Scan Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setScanning(false);
    }
  });
  
  const handleUpload = () => {
    // Navigate to dedicated scanner page with camera tab active
    navigate('/scan-medication');
  };

  return (
    <div className="bg-white rounded-2xl p-6 card-shadow overflow-hidden relative">
      <h2 className="text-lg font-display font-semibold text-gray-800 mb-2">Prescription Scanner</h2>
      <p className="text-sm text-gray-500 mb-4">Upload or scan your prescription to add medications automatically.</p>
      
      <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center">
        <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center mb-3">
          <span className="material-icons text-secondary">document_scanner</span>
        </div>
        <p className="text-sm text-gray-500 text-center mb-2">Drag and drop your prescription or</p>
        <button 
          className="py-2 px-4 rounded-lg bg-secondary/10 text-secondary text-sm font-medium"
          onClick={handleUpload}
        >
          <span className="flex items-center">
            <span className="material-icons mr-2 text-sm">photo_camera</span>
            Use Prescription Scanner
          </span>
        </button>
      </div>
    </div>
  );
};

// Reminders Card
const RemindersCard: React.FC = () => {
  const [notifications, setNotifications] = useState(true);
  const [sms, setSms] = useState(true);
  const [email, setEmail] = useState(false);

  return (
    <div className="bg-gradient-to-br from-accent/90 to-primary/90 text-white rounded-2xl p-6 card-shadow overflow-hidden relative">
      <h2 className="text-lg font-display font-semibold mb-2">Medication Reminders</h2>
      <p className="text-sm text-white/80 mb-4">Configure how you want to receive medication alerts.</p>
      
      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between bg-white/10 rounded-lg p-3">
          <div className="flex items-center">
            <span className="material-icons mr-3">notifications</span>
            <span className="text-sm">Push Notifications</span>
          </div>
          <button 
            className={`w-12 h-6 rounded-full relative p-1 transition-colors ${notifications ? 'bg-white/30' : 'bg-white/10'}`}
            onClick={() => setNotifications(!notifications)}
          >
            <div 
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${notifications ? 'right-1' : 'left-1'}`}
            ></div>
          </button>
        </div>
        
        <div className="flex items-center justify-between bg-white/10 rounded-lg p-3">
          <div className="flex items-center">
            <span className="material-icons mr-3">sms</span>
            <span className="text-sm">SMS Reminders</span>
          </div>
          <button 
            className={`w-12 h-6 rounded-full relative p-1 transition-colors ${sms ? 'bg-white/30' : 'bg-white/10'}`}
            onClick={() => setSms(!sms)}
          >
            <div 
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${sms ? 'right-1' : 'left-1'}`}
            ></div>
          </button>
        </div>
        
        <div className="flex items-center justify-between bg-white/10 rounded-lg p-3">
          <div className="flex items-center">
            <span className="material-icons mr-3">email</span>
            <span className="text-sm">Email Alerts</span>
          </div>
          <button 
            className={`w-12 h-6 rounded-full relative p-1 transition-colors ${email ? 'bg-white/30' : 'bg-white/10'}`}
            onClick={() => setEmail(!email)}
          >
            <div 
              className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${email ? 'right-1' : 'left-1'}`}
            ></div>
          </button>
        </div>
      </div>
      
      <button className="py-2 px-4 rounded-lg bg-white text-accent text-sm font-medium">
        Configure Reminders
      </button>
    </div>
  );
};

// Feature Cards container component
const FeatureCards: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      <NFCScanCard />
      <PrescriptionScannerCard />
      <RemindersCard />
    </div>
  );
};

export default FeatureCards;
