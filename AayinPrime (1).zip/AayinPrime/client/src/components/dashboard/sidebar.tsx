import React from 'react';
import { useLocation, Link } from 'wouter';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/use-auth';

interface SidebarItemProps {
  icon: string;
  label: string;
  href: string;
  active?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, href, active }) => {
  return (
    <Link href={href}>
      <div className={cn(
        "flex items-center justify-center md:justify-start p-2 md:pl-3 md:pr-4 rounded-xl transition group",
        active 
          ? "bg-primary/20 text-primary" 
          : "text-gray-400 hover:bg-white/10"
      )}>
        <span className="material-icons">{icon}</span>
        <span className="hidden md:block ml-3">{label}</span>
        {active && <span className="hidden md:block ml-auto w-2 h-2 rounded-full bg-primary"></span>}
      </div>
    </Link>
  );
};

const Sidebar: React.FC = () => {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
  };

  return (
    <aside className="w-20 md:w-64 bg-dark text-white flex flex-col">
      {/* Logo */}
      <div className="p-4 flex items-center justify-center md:justify-start">
        <div className="hidden md:flex flex-col">
          <span className="font-display font-bold text-lg text-white">Welcome To</span>
          <span className="font-display text-md text-white -mt-1">Artis Symbiose</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <SidebarItem 
          icon="dashboard" 
          label="Dashboard" 
          href="/dashboard" 
          active={location === '/dashboard'} 
        />
        <SidebarItem 
          icon="medication" 
          label="Medications" 
          href="/medications" 
          active={location === '/medications'} 
        />
        <SidebarItem 
          icon="event_note" 
          label="Prescriptions" 
          href="/prescriptions" 
          active={location === '/prescriptions'} 
        />
        <SidebarItem
          icon="verified_user"
          label="Create Implant Verification"
          href="/dashboard/create-implant"
          active={location === '/dashboard/create-implant'}
        />
      </nav>

      {/* User */}
      <div className="p-4">
        <div className="p-2 rounded-xl hover:bg-white/10 transition flex items-center justify-center md:justify-start">
          <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
            <span className="material-icons text-sm">person</span>
          </div>
          <div className="hidden md:block ml-3">
            <div className="text-sm font-medium">{user?.name || user?.username}</div>
            <div className="text-xs text-gray-400">{user?.role || 'Patient'}</div>
          </div>
          <button 
            className="hidden md:block ml-auto"
            onClick={handleLogout}
          >
            <span className="material-icons text-gray-400">logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

// New component for creating implant verification numbers
export const CreateImplant = () => {
  // Add form logic here to collect patient details and generate verification number.
  return (
    <div>
      <h1>Create Implant Verification Number</h1>
      {/* Form to collect patient details and generate verification number */}
    </div>
  );
};

export default Sidebar;