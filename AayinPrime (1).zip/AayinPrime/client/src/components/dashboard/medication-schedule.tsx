import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Medication } from '@shared/schema';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

interface MedicationItemProps {
  medication: Medication;
  onStatusChange: (id: number, status: string) => void;
}

const MedicationItem: React.FC<MedicationItemProps> = ({ medication, onStatusChange }) => {
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'taken':
        return 'text-success';
      case 'due':
        return 'text-primary';
      case 'upcoming':
        return 'text-gray-500';
      default:
        return 'text-gray-500';
    }
  };
  
  const getStatusText = (status: string) => {
    switch (status) {
      case 'taken':
        return '✓ Taken';
      case 'due':
        return 'Due now';
      case 'upcoming':
        return 'Upcoming';
      default:
        return status;
    }
  };
  
  const handleMarkAsTaken = () => {
    onStatusChange(medication.id, 'taken');
  };
  
  return (
    <div className={cn(
      "flex items-center p-3 rounded-xl transition",
      medication.status === 'due' 
        ? "bg-primary/5 hover:bg-primary/10 border border-primary/20" 
        : "hover:bg-gray-50"
    )}>
      <div className={cn(
        "w-12 h-12 rounded-xl flex items-center justify-center mr-4",
        medication.status === 'due' 
          ? "bg-primary/10 animate-pulse" 
          : medication.status === 'taken' 
            ? "bg-primary/10" 
            : "bg-gray-100"
      )}>
        <span className={cn(
          "material-icons",
          medication.status === 'due' || medication.status === 'taken'
            ? "text-primary"
            : "text-gray-500"
        )}>medication</span>
      </div>
      
      <div className="flex-1">
        <h3 className="font-medium">{medication.name}</h3>
        <p className="text-sm text-gray-500">{medication.dosage}, {medication.frequency}</p>
      </div>
      
      <div className="text-right">
        <p className={cn(
          "font-mono text-sm font-bold",
          medication.status === 'due' ? "text-primary" : medication.status === 'upcoming' ? "text-gray-500" : ""
        )}>{medication.time}</p>
        <p className={cn("text-xs", getStatusClass(medication.status))}>{getStatusText(medication.status)}</p>
      </div>
      
      {medication.status === 'due' && (
        <button 
          className="ml-4 p-2 rounded-full bg-primary text-white"
          onClick={handleMarkAsTaken}
        >
          <span className="material-icons">check</span>
        </button>
      )}
    </div>
  );
};

const MedicationSchedule: React.FC = () => {
  const { toast } = useToast();
  
  const { data: medications, isLoading } = useQuery<Medication[]>({
    queryKey: ['/api/medications'],
  });
  
  const updateMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest('PUT', `/api/medications/${id}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
      toast({
        title: "Medication updated",
        description: "Your medication status has been updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update medication",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleStatusChange = (id: number, status: string) => {
    updateMutation.mutate({ id, status });
  };
  
  return (
    <div className="lg:col-span-2 bg-white rounded-2xl p-6 card-shadow">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-display font-semibold text-gray-800">Medication Schedule</h2>
        <button className="text-primary text-sm font-medium">View All</button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : medications && medications.length > 0 ? (
        <div className="space-y-4">
          {medications.map(medication => (
            <MedicationItem 
              key={medication.id} 
              medication={medication} 
              onStatusChange={handleStatusChange}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-gray-500">
          <div className="mb-4">
            <span className="material-icons text-4xl">medication</span>
          </div>
          <p className="mb-2">No medications scheduled</p>
          <p className="text-sm text-gray-400">Add your medications to get reminders</p>
        </div>
      )}
      
      <button className="mt-4 flex items-center justify-center w-full py-3 rounded-xl border border-dashed border-gray-300 text-primary hover:bg-primary/5 transition">
        <span className="material-icons mr-2">add</span>
        <span>Add Medication</span>
      </button>
    </div>
  );
};

export default MedicationSchedule;
