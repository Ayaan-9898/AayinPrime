import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import OTPInput from './otp-input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EmailVerificationProps {
  email: string;
  onVerified: (userData: any) => void;
  onCancel: () => void;
  isRegistration?: boolean;
}

export default function EmailVerification({ email, onVerified, onCancel, isRegistration = false }: EmailVerificationProps) {
  const [otp, setOtp] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [error, setError] = useState(""); // Added error state
  const { toast } = useToast();

  const handleVerify = async () => {
    try {
      setIsSubmitting(true);
      setError(""); // Clear error on new attempt

      if (otp.length !== 6) {
        setError("Please enter the complete 6-digit verification code");
        return;
      }

      const endpoint = isRegistration ? '/api/verify-email' : '/api/login-verify';
      const response = await apiRequest('POST', endpoint, { email, code: otp });
      const data = await response.json();

      if (response.ok && data.success) {
        toast({
          title: "Verification successful",
          description: isRegistration ? "Your account has been verified" : "Login successful",
        });
        onVerified(data.user);
      } else {
        setError(data.message || "Invalid or expired verification code");
        toast({
          title: "Verification failed",
          description: data.message || "Invalid or expired verification code",
          variant: "destructive",
        });
      }
    } catch (error) {
      setError("An error occurred during verification. Please try again.");
      toast({
        title: "Error",
        description: "An error occurred during verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendCode = async () => {
    setIsResending(true);
    try {
      const endpoint = isRegistration ? '/api/resend-verification' : '/api/login-request';
      const body = isRegistration ? { email } : { username: email };
      const response = await apiRequest('POST', endpoint, body);
      const data = await response.json();

      if (response.ok && data.success) {
        toast({
          title: "Code resent",
          description: "A new verification code has been sent to your email",
        });
      } else {
        toast({
          title: "Failed to resend code",
          description: data.message || "An error occurred while sending the code",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while resending the code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsResending(false);
    }
  };

  // Extract masked email for display
  const displayEmail = email.replace(/(.{2})(.*)(?=@)/, (_, a, b) => a + b.replace(/./g, '*'));

  return (
    <Card className="w-full max-w-md mx-auto border-primary/20 shadow-lg">
      <CardHeader className="space-y-2 text-center">
        <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
            <rect width="16" height="13" x="4" y="5" rx="2"/>
            <path d="m22 5-8 5-8-5"/>
            <path d="M20 18V9"/>
            <path d="M4 13v5"/>
          </svg>
        </div>
        <CardTitle className="text-2xl font-bold">Email Verification</CardTitle>
        <CardDescription>
          We've sent a 6-digit verification code to<br />
          <span className="font-medium text-foreground">{displayEmail}</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="py-4">
          <OTPInput 
            length={6} 
            value={otp} 
            onChange={setOtp} 
            autoFocus
          />
          {error && <p className="text-red-500 text-xs mt-1">{error}</p>} {/* Display error */}
        </div>
        <div className="text-sm text-center space-y-1">
          <p className="text-muted-foreground">This code will expire in 15 minutes</p>
          <div>
            <span className="text-muted-foreground">Didn't receive the code?</span>{" "}
            <button 
              onClick={handleResendCode} 
              disabled={isResending}
              className="text-primary hover:underline font-medium disabled:opacity-50 inline-flex items-center"
            >
              {isResending ? (
                <span className="flex items-center gap-1">
                  <Loader2 className="h-3 w-3 animate-spin" /> Resending...
                </span>
              ) : (
                "Resend code"
              )}
            </button>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-3 pb-6">
        <Button 
          className="w-full" 
          onClick={handleVerify}
          disabled={otp.length !== 6 || isSubmitting}
          size="lg"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" /> Verifying...
            </span>
          ) : (
            "Verify & Continue"
          )}
        </Button>
        <Button 
          variant="ghost" 
          className="w-full text-muted-foreground hover:text-foreground" 
          onClick={onCancel}
          disabled={isSubmitting}
        >
          Back to {isRegistration ? "Registration" : "Login"}
        </Button>
      </CardFooter>
    </Card>
  );
}