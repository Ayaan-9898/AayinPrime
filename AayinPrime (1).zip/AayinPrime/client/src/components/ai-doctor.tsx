
import React, { useState, useRef, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/api';

const AiDoctor: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const aiMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest('POST', '/api/ai/doctor', { message });
      return res.json();
    },
    onSuccess: (data) => {
      setMessages(prev => [...prev, { role: 'assistant', content: data.message }]);
      setInput('');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    setMessages(prev => [...prev, { role: 'user', content: input }]);
    aiMutation.mutate(input);
  };

  return (
    <div className={`fixed bottom-4 right-4 z-50 ${isOpen ? 'w-80' : 'w-16'}`}>
      {isOpen && (
        <div className="bg-white rounded-lg shadow-xl p-4 mb-4 h-96 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-primary">AI Doctor</h3>
            <button onClick={() => setIsOpen(false)} className="text-gray-500">×</button>
          </div>
          
          <div className="flex-1 overflow-y-auto mb-4">
            {messages.length === 0 && (
              <div className="text-center text-gray-500 mt-4">
                <p>Welcome to AI Doctor</p>
                <p className="text-xs mt-2">Ask me anything about eye health or medications</p>
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`mb-2 ${msg.role === 'user' ? 'text-right' : ''}`}>
                <div className={`inline-block p-2 rounded-lg ${
                  msg.role === 'user' ? 'bg-primary text-white' : 'bg-gray-100'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about eye health..."
              className="flex-1 px-3 py-2 border rounded-lg"
            />
            <button 
              type="submit" 
              disabled={aiMutation.isPending}
              className="bg-primary text-white px-4 py-2 rounded-lg"
            >
              {aiMutation.isPending ? "..." : "Send"}
            </button>
          </form>
        </div>
      )}
      
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
          title="Ask AI Doctor"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 15h18M3 9h18"></path>
            <circle cx="12" cy="12" r="9"></circle>
            <path d="M9 9h.01M15 9h.01"></path>
            <path d="M8 13a4 4 0 0 0 8 0"></path>
          </svg>
        </button>
      )}
    </div>
  );
};

export default AiDoctor;
