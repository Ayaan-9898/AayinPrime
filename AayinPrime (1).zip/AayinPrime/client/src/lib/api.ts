export async function apiRequest(method: string, path: string, body?: any, baseUrl: string = '/api') {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include',
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    // Add a timeout to the fetch to prevent hanging requests
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 seconds timeout
    
    const response = await fetch(baseUrl + path, {
      ...options,
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      let errorMessage = `API request failed: ${response.statusText}`;
      
      try {
        // Try to parse error as JSON
        const errorJson = JSON.parse(errorText);
        if (errorJson.message) {
          errorMessage = errorJson.message;
        }
      } catch (e) {
        // If parsing fails, use the raw text
        if (errorText) {
          errorMessage = errorText;
        }
      }
      
      throw new Error(errorMessage);
    }

    return response;
  } catch (error: unknown) {
    // Handle AbortError specifically
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error('Request timed out. Please try again.');
    }
    
    // Log the error for debugging purposes
    console.error('API request error:', error);
    
    // Convert unknown errors to Error objects if needed
    if (!(error instanceof Error)) {
      throw new Error(String(error));
    }
    
    // Re-throw the error so it can be handled by the caller
    throw error;
  }
}