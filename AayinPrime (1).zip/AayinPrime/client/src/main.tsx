import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import App from "./App";
import "./index.css";
import ErrorBoundary from "@/components/error-boundary";

// Global error handler for uncaught promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled Promise Rejection:', event.reason);
  
  // Prevent the default browser behavior which might show default error pages
  event.preventDefault();
});

// Global error handler for unexpected errors
window.addEventListener('error', (event) => {
  console.error('Global error caught:', event.error);
  
  // Prevent the default browser behavior
  event.preventDefault();
});

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>
);
