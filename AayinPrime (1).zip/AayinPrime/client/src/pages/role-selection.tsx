import React from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from '@/hooks/use-toast';

const RoleSelection: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const selectRole = (role: 'patient' | 'hospital') => {
    // Store the selected role in localStorage
    localStorage.setItem('userRole', role);
    
    // Show toast notification
    toast({
      title: `${role.charAt(0).toUpperCase() + role.slice(1)} Role Selected`,
      description: `You've selected the ${role} role.`
    });
    
    // Navigate to auth page
    setLocation('/auth');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-primary/10 to-background">
      <div className="container max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-8">Welcome to Artis Symbiose</h1>
        <p className="text-center text-muted-foreground mb-12">
          Please select your role to continue
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Patient Role Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="bg-primary/5 rounded-t-lg">
              <CardTitle className="text-xl">Patient</CardTitle>
              <CardDescription>Individual healthcare management</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Track medications and appointments
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> NFC implant verification
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> AI-powered health assistant
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Medication reminders
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                onClick={() => selectRole('patient')}
              >
                Continue as Patient
              </Button>
            </CardFooter>
          </Card>
          
          {/* Hospital Role Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="bg-primary/5 rounded-t-lg">
              <CardTitle className="text-xl">Hospital</CardTitle>
              <CardDescription>Healthcare provider management</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Manage patient medications
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Schedule appointments
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> View patient analytics
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Electronic prescription system
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full bg-primary/90 hover:bg-primary" 
                onClick={() => selectRole('hospital')}
              >
                Continue as Hospital
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;