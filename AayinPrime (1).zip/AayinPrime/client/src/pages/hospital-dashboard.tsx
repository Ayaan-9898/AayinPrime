import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { User } from '@shared/schema';
import { useLocation } from 'wouter';

const HospitalDashboard: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('data');
  const [verificationNumber, setVerificationNumber] = useState('');
  const [medicationError, setMedicationError] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<User | null>(null);
  const [showMedicationEditor, setShowMedicationEditor] = useState(false);
  
  const [showUpdateDialog, setShowUpdateDialog] = useState(false); // Added state for update dialog
  const [updateForm, setUpdateForm] = useState({
    hospitalName: user?.hospitalName || '',
    hospitalAddress: user?.hospitalAddress || '',
    hospitalState: user?.hospitalState || ''
  });

  const handleAddPatient = async () => {
    try {
      if (!newPatientForm.email || !newPatientForm.name) {
        toast({
          title: "Error",
          description: "Name and email are required",
          variant: "destructive"
        });
        return;
      }

      const passcode = Math.random().toString().slice(2, 8);

      const response = await fetch('/api/hospital/create-patient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...newPatientForm,
          passcode,
          hospitalName: user?.hospitalName,
          city: user?.city,
          state: user?.state
        }),
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Success",
          description: `Patient invitation sent to ${newPatientForm.email}`,
        });
        setNewPatientDialog(false);
        refetchPatients();
      } else {
        throw new Error(data.message || 'Failed to add patient');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add patient",
        variant: "destructive"
      });
    }
  };

  const [searchForm, setSearchForm] = useState({
    name: '',
    city: '',
    implantNumber: ''
  });

  const handlePatientSearch = async () => {
    try {
      const response = await fetch('/api/hospital/search-patient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(searchForm),
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok && data.patient) {
        setSelectedPatient(data.patient);
        setActiveTab('patient');
      } else {
        toast({
          title: "Not Found",
          description: "Patient not found with given details",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to search patient",
        variant: "destructive"
      });
    }
  };


  // Fetch patients for this hospital
  const { data: patients, refetch: refetchPatients } = useQuery({
    queryKey: ['/api/hospital/patients'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/hospital/patients');
      return res.json();
    }
  });

  // Mutation for updating patient medication
  const updateMedicationMutation = useMutation<
    any, // success response type
    Error, // error type
    {
      patientId: number;
      implantNumber: string;
      medicationData: {
        name: string;
        dosage: string;
        frequency: string;
        startDate: string;
        endDate: string;
      }
    } // variables type
  >({
    mutationFn: async (variables) => {
      const { patientId, implantNumber, medicationData } = variables;
      const res = await apiRequest('POST', `/api/hospital/patient/${patientId}/medication`, {
        implantVerificationNumber: implantNumber,
        ...medicationData
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Medication Updated",
        description: "Patient medication has been updated successfully"
      });
      setShowMedicationEditor(false);
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update patient medication",
        variant: "destructive"
      });
    }
  });

  // Mutation for creating a new patient
  const createPatientMutation = useMutation<
    any, // success response type
    Error, // error type
    {
      name: string;
      email: string;
      phone: string;
      location: string;
      hospitalId?: number;
      implantVerificationNumber: string;
    } // variables type
  >({
    mutationFn: async (variables) => {
      const res = await apiRequest('POST', '/api/hospital/create-patient', variables);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Patient Created",
        description: "New patient has been added successfully"
      });
      refetchPatients();
      setNewPatientDialog(false);
      setNewPatientForm({
        name: '',
        email: '',
        phone: '',
        location: ''
      });
    },
    onError: (error) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create new patient",
        variant: "destructive"
      });
    }
  });

  const handleSelectPatient = (patient: User) => {
    setSelectedPatient(patient);
    setActiveTab('patient');
  };

  const handleUpdateMedication = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedPatient) {
      setMedicationError("No patient selected");
      return;
    }

    if (!verificationNumber) {
      setMedicationError("Verification number is required");
      return;
    }

    updateMedicationMutation.mutate({
      patientId: selectedPatient.id,
      implantNumber: verificationNumber,
      medicationData: {
        name: "Updated Medication",
        dosage: "1 tablet",
        frequency: "daily",
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      }
    });
  };

  const handleCreatePatient = (e: React.FormEvent) => {
    e.preventDefault();

    if (!newPatientForm.name || !newPatientForm.email) {
      toast({
        title: "Missing Information",
        description: "Name and email are required",
        variant: "destructive"
      });
      return;
    }

    createPatientMutation.mutate({
      ...newPatientForm,
      hospitalId: user?.id,
      implantVerificationNumber: Math.random().toString(36).substring(2, 10).toUpperCase()
    });
  };

  const handleUpdateHospital = async () => {
    try {
      const response = await fetch('/api/hospital/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateForm),
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Failed to update hospital information: ${response.status}`);
      }

      toast({ title: 'Hospital information updated successfully!' });
      setShowUpdateDialog(false);
      // Optionally refetch hospital data here.
    } catch (error) {
      toast({ title: 'Error updating hospital information.', description: error instanceof Error ? error.message : 'An unknown error occurred.', variant: 'destructive' });
    }
  };


  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Hospital Dashboard</h1>
        <Button
          variant="outline"
          onClick={() => setLocation('/issue-implant')}
        >
          Issue Implant Number
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="data">Hospital Data</TabsTrigger>
          <TabsTrigger value="patients">Patients</TabsTrigger>
          {selectedPatient && <TabsTrigger value="patient">Patient Detail</TabsTrigger>}
        </TabsList>

        <TabsContent value="data">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Hospital Details</CardTitle>
                <CardDescription>Your hospital information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p><strong>Name:</strong> {user?.hospitalName || user?.name || 'Artis Medical Center'}</p>
                  <p><strong>Address:</strong> {user?.hospitalAddress || '123 Medical Parkway, Suite 100'}</p>
                  <p><strong>State:</strong> {user?.hospitalState || 'California'}</p>
                  <p><strong>License ID:</strong> {user?.licenseId || 'HSP-123456'}
                    {user?.licenseVerified &&
                      <Badge className="ml-2 bg-green-500">Verified</Badge>
                    }
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" onClick={() => setShowUpdateDialog(true)}>Update Information</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hospital Statistics</CardTitle>
                <CardDescription>Overview of your hospital data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Total Patients</span>
                    <span className="text-xl font-bold">{patients?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Active Implants</span>
                    <span className="text-xl font-bold">{patients?.filter((p: any) => p.isVerified)?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Pending Verifications</span>
                    <span className="text-xl font-bold">{patients?.filter((p: any) => !p.isVerified)?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Active Prescriptions</span>
                    <span className="text-xl font-bold">12</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="patients">
          <Card>
            <CardHeader>
              <CardTitle>Patient Management</CardTitle>
              <CardDescription>View and manage your patients</CardDescription>
            </CardHeader>
            <CardContent>
              {patients && patients.length > 0 ? (
                <div className="border rounded-md divide-y">
                  {patients.map((patient: any) => (
                    <div key={patient.id} className="p-4 flex justify-between items-center hover:bg-slate-50">
                      <div>
                        <h3 className="font-medium">{patient.name}</h3>
                        <p className="text-sm text-muted-foreground">{patient.email}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant={patient.isVerified ? "default" : "outline"}>
                            {patient.isVerified ? "Verified" : "Pending"}
                          </Badge>
                          {patient.implantVerificationId && (
                            <Badge variant="secondary" className="text-xs">
                              ID: {patient.implantVerificationId}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button size="sm" onClick={() => handleSelectPatient(patient)}>
                        Manage
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center">
                  <p className="text-muted-foreground">No patients found</p>
                  <Button className="mt-4" onClick={() => setNewPatientDialog(true)}>
                    Add Your First Patient
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patient">
          {selectedPatient && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>{selectedPatient.name}</CardTitle>
                  <CardDescription>
                    Patient ID: {selectedPatient.id}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p><strong>Email:</strong> {selectedPatient.email}</p>
                    <p><strong>Phone:</strong> {selectedPatient.phone}</p>
                    <p><strong>Location:</strong> {selectedPatient.location}</p>
                    <p>
                      <strong>Implant Status:</strong>{" "}
                      <Badge variant={selectedPatient.isVerified ? "default" : "outline"}>
                        {selectedPatient.isVerified ? "Verified" : "Pending"}
                      </Badge>
                    </p>
                    <p><strong>Verification ID:</strong> {selectedPatient.implantVerificationId}</p>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" onClick={() => setShowMedicationEditor(true)}>
                    Update Medications
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Health Records</CardTitle>
                  <CardDescription>Patient health information</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium">Last Appointment</h3>
                      <p className="text-sm text-muted-foreground">March 15, 2024</p>
                    </div>
                    <div>
                      <h3 className="font-medium">Current Medications</h3>
                      <ul className="text-sm text-muted-foreground mt-1 space-y-1">
                        <li>• Lumega-XR 10mg - 1 tablet daily</li>
                        <li>• Visidrop 0.5% - 1 drop both eyes twice daily</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-medium">Implant History</h3>
                      <p className="text-sm text-muted-foreground">Implanted: January 10, 2023</p>
                      <p className="text-sm text-muted-foreground">Last Check: February 20, 2024</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="flex gap-2 w-full">
                    <Button variant="outline" className="flex-1">View Full History</Button>
                    <Button className="flex-1">Schedule Appointment</Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Medication Editor Dialog */}
      <Dialog open={showMedicationEditor} onOpenChange={setShowMedicationEditor}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Patient Medication</DialogTitle>
            <DialogDescription>
              Enter the patient's implant verification number to update their medication
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleUpdateMedication}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="verification">Implant Verification Number</Label>
                <Input
                  id="verification"
                  value={verificationNumber}
                  onChange={(e) => setVerificationNumber(e.target.value)}
                  placeholder="Enter verification number"
                />
              </div>

              {medicationError && (
                <p className="text-destructive text-sm">{medicationError}</p>
              )}
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowMedicationEditor(false)}>
                Cancel
              </Button>
              <Button type="submit">Update Medication</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      

      {/* Update Hospital Dialog */}
      <Dialog open={showUpdateDialog} onOpenChange={setShowUpdateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Hospital Information</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleUpdateHospital}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="hospitalName">Hospital Name</Label>
                <Input id="hospitalName" type="text" value={updateForm.hospitalName} onChange={(e) => setUpdateForm({ ...updateForm, hospitalName: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="hospitalAddress">Hospital Address</Label>
                <Input id="hospitalAddress" type="text" value={updateForm.hospitalAddress} onChange={(e) => setUpdateForm({ ...updateForm, hospitalAddress: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="hospitalState">Hospital State</Label>
                <Input id="hospitalState" type="text" value={updateForm.hospitalState} onChange={(e) => setUpdateForm({ ...updateForm, hospitalState: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowUpdateDialog(false)}>Cancel</Button>
              <Button type="submit">Update</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Search Patient</CardTitle>
          <CardDescription>Search for a patient to edit their dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="patientName">Patient Name</Label>
              <Input
                id="patientName"
                value={searchForm.name}
                onChange={(e) => setSearchForm({ ...searchForm, name: e.target.value })}
                placeholder="Enter patient name"
              />
            </div>
            <div>
              <Label htmlFor="patientCity">City</Label>
              <Input
                id="patientCity"
                value={searchForm.city}
                onChange={(e) => setSearchForm({ ...searchForm, city: e.target.value })}
                placeholder="Enter city"
              />
            </div>
            <div>
              <Label htmlFor="implantNumber">Implant Number</Label>
              <Input
                id="implantNumber"
                value={searchForm.implantNumber}
                onChange={(e) => setSearchForm({ ...searchForm, implantNumber: e.target.value })}
                placeholder="Enter implant verification number"
              />
            </div>
            <Button onClick={handlePatientSearch} className="w-full">
              Search Patient
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HospitalDashboard;