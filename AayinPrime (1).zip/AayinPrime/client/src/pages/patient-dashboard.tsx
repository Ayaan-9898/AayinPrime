import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import MedicationSchedule from '@/components/dashboard/medication-schedule';
import AppointmentTable from '@/components/dashboard/appointment-table';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { Calendar, Pill, Stethoscope, User } from 'lucide-react';

const PatientDashboard = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  if (!user) return null;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Patient Dashboard</h1>
        <Button onClick={() => setLocation('/scan-medication')}>
          Scan Medication
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="font-medium">Name:</label>
                <p>{user.name}</p>
              </div>
              <div>
                <label className="font-medium">Email:</label>
                <p>{user.email}</p>
              </div>
              <div>
                <label className="font-medium">Hospital:</label>
                <p>{user.hospitalName || 'Not assigned'}</p>
              </div>
              <div>
                <label className="font-medium">Implant Number:</label>
                <p>{user.implantVerificationNumber || 'Not assigned'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" onClick={() => setLocation('/schedule-appointment')}>
              <Calendar className="h-4 w-4 mr-2" />
              Schedule Appointment
            </Button>
            <Button className="w-full" variant="outline" onClick={() => setLocation('/medications')}>
              <Pill className="h-4 w-4 mr-2" />
              View Medications
            </Button>
            <Button className="w-full" variant="outline" onClick={() => setLocation('/scan-medication')}>
              <Stethoscope className="h-4 w-4 mr-2" />
              Scan New Medication
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MedicationSchedule />
        <AppointmentTable />
      </div>
    </div>
  );
};

export default PatientDashboard;