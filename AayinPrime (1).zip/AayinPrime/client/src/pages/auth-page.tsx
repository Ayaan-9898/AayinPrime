import React, { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import EmailVerification from "@/components/email-verification";
import ImplantPrompt from "@/components/implant-prompt";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const { toast } = useToast();
  const [isLogin, setIsLogin] = useState(true);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    name: "",
    email: "",
    role: "",
    licenseId: "",
    phone: "",
    location: "",
    hospitalName: "",
    city: "",
    state: ""
  });

// Clear form on component mount
React.useEffect(() => {
    setFormData({
      username: "",
      password: "",
      name: "",
      email: "",
      role: "",
      licenseId: "",
      phone: "",
      location: "",
      hospitalName: "",
      city: "",
      state: ""
    });
}, []);
  const [error, setError] = useState("");
  const [licenseVerificationStep, setLicenseVerificationStep] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showImplantPrompt, setShowImplantPrompt] = useState(false);
  const [pendingUser, setPendingUser] = useState<any>(null);

  // Email verification states
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState("");
  const [isRegistrationVerification, setIsRegistrationVerification] = useState(false);

  // Get the stored role from localStorage, if available
  React.useEffect(() => {
    const storedRole = localStorage.getItem('userRole');
    if (storedRole) {
      setSelectedRole(storedRole);
      setFormData(prev => ({ ...prev, role: storedRole }));
    }
  }, []);

  // Redirect if user is already logged in
  React.useEffect(() => {
    if (user) {
      if (user.role === 'patient') {
        setLocation('/patient-dashboard');
      } else if (user.role === 'hospital') {
        setLocation('/hospital-dashboard');
      } else {
        setLocation('/dashboard');
      }
    }
  }, [user, setLocation]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsSubmitting(true);

    console.log("Form submission starting", { isLogin, formData, selectedRole });

    try {
      if (isLogin) {
        try {
          const response = await loginMutation.mutateAsync({ 
            username: formData.username, 
            password: formData.password 
          });

          if (response) {
            // Redirect based on role
            if (response.role === 'patient') {
              // Show implant verification prompt after patient login
              setPendingUser(response);
              setShowImplantPrompt(true);
            } else if (response.role === 'hospital') {
              // Redirect to hospital license verification if not verified
              if (!response.licenseVerified) {
                setLocation('/verify-license');
              } else {
                setLocation('/hospital-dashboard');
              }
            } else {
              setLocation('/dashboard');
            }
          }
        } catch (err) {
          setError("Login failed. Please check your credentials.");
        }
      } else {
        if (licenseVerificationStep) {
          // License verification successful, proceed with registration
          registerMutation.mutate(
            { 
              ...formData, 
              role: selectedRole || 'hospital',
              isVerified: false,
              licenseVerified: true // Pre-verified from the license step
            },
            {
              onSuccess: (data) => {
                // Always show email verification if email exists
                if (formData.email) {
                  setVerificationEmail(formData.email);
                  setIsRegistrationVerification(true);
                  setShowEmailVerification(true);
                } else {
                  // Hospital goes directly to hospital dashboard
                  setLocation("/hospital-dashboard");
                }
              },
              onError: (err) => {
                // Improved error handling: Check for specific error and display appropriate message.
                const errorMessage = err instanceof Error ? err.message : "Registration failed. Please try again.";
                if (errorMessage.includes("Username already exists")) {
                  setError("A user with that username already exists. Please choose a different username.");
                } else {
                  setError(errorMessage);
                }
              }
            }
          );
        } else if (!selectedRole) {
          toast({
            title: "Error",
            description: "Please select a role",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        } else {
          // Proceed with registration if role is selected
          registerMutation.mutate(
            { 
              ...formData, 
              role: selectedRole,
              isVerified: false
            },
            {
              onSuccess: (data) => {
                // Always show email verification if email exists
                if (formData.email) {
                  setVerificationEmail(formData.email);
                  setIsRegistrationVerification(true);
                  setShowEmailVerification(true);
                } else {
                  // After registration, direct patients to implant verification or dashboard based on role
                  if (selectedRole === 'patient') {
                    setLocation("/implant-verification");
                  } else if (selectedRole === 'hospital') {
                    setLocation("/hospital-dashboard");
                  } else {
                    setLocation("/dashboard");
                  }
                }
              },
              onError: (err) => {
                // Improved error handling: Check for specific error and display appropriate message.
                const errorMessage = err instanceof Error ? err.message : "Registration failed. Please try again.";
                if (errorMessage.includes("Username already exists")) {
                  setError("A user with that username already exists. Please choose a different username.");
                } else {
                  setError(errorMessage);
                }
              }
            }
          );
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle verification completion
  const handleVerificationComplete = (userData: any) => {
    // Store role in localStorage
    if (userData && userData.role) {
      localStorage.setItem('userRole', userData.role);
    }

    // Redirect based on role
    if (userData && userData.role === 'patient') {
      setLocation("/implant-verification");
    } else if (userData && userData.role === 'hospital') {
      setLocation("/hospital-dashboard");
    } else {
      setLocation("/dashboard");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
    setFormData({ ...formData, role });

    console.log(`Selected role: ${role}`);

    if (role === 'hospital') {
      setLicenseVerificationStep(true);
      console.log("Setting license verification step to true");
    }
  };

  const verifyLicense = async () => {
    setIsSubmitting(true);
    setError("");

    console.log("Starting license verification with:", formData.licenseId);

    try {
      const response = await fetch('/api/hospital/verify-license', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ licenseId: formData.licenseId }),
      });

      const data = await response.json();
      console.log("License verification response:", data);

      if (data.verified) {
        toast({
          title: "License Verified",
          description: data.message || "License has been verified successfully",
          variant: "default",
        });

        // Make sure role is set to hospital
        setFormData(prev => ({ 
          ...prev, 
          role: 'hospital',
          licenseVerified: true
        }));

        console.log("License verified, role set to hospital");
        setLicenseVerificationStep(false);
      } else {
        setError(data.message || "Invalid license ID. Please enter a valid hospital license.");
      }
    } catch (err) {
      console.error("License verification error:", err);
      setError("Failed to verify license. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (licenseVerificationStep) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Hospital License Verification</CardTitle>
            </CardHeader>
            <CardContent>
              {error && (
                <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm">
                  {error}
                </div>
              )}
              <div className="space-y-5">
                <div className="space-y-2">
                  <Label>License ID</Label>
                  <Input
                    type="text"
                    value={formData.licenseId}
                    onChange={handleChange}
                    name="licenseId"
                    placeholder="Enter hospital license ID"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Button 
                    onClick={verifyLicense} 
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify License"
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!selectedRole) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Choose Your Role</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button
                  onClick={() => handleRoleSelect('patient')}
                  className="w-full h-20 text-lg"
                  variant="outline"
                >
                  <span className="material-icons mr-2 text-2xl">person</span>
                  Patient
                </Button>
                <Button
                  onClick={() => handleRoleSelect('hospital')}
                  className="w-full h-20 text-lg"
                  variant="outline"
                >
                  <span className="material-icons mr-2 text-2xl">local_hospital</span>
                  Hospital
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const handleImplantPromptComplete = (hasImplant: boolean) => {
    setShowImplantPrompt(false);
    
    // Redirect based on implant verification result
    if (hasImplant) {
      toast({
        title: "Welcome",
        description: "Implant verified successfully. Redirecting to dashboard..."
      });
    } else {
      toast({
        title: "Welcome",
        description: "Proceeding without implant verification. Redirecting to dashboard..."
      });
    }
    
    setLocation("/dashboard");
  };

  const handleImplantPromptSkip = () => {
    setShowImplantPrompt(false);
    setLocation("/dashboard");
  };

  // If showing implant prompt, render that instead of the login/register form
  if (showImplantPrompt) {
    return (
      <ImplantPrompt
        onComplete={handleImplantPromptComplete}
        onSkip={handleImplantPromptSkip}
      />
    );
  }

  // If showing email verification, render that instead of the login/register form
  if (showEmailVerification) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <EmailVerification 
          email={verificationEmail}
          onVerified={handleVerificationComplete}
          onCancel={() => setShowEmailVerification(false)}
          isRegistration={isRegistrationVerification}
        />
      </div>
    );
  }

  // Main login/register form
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-center gap-8">
          <div className="w-full md:w-1/2 p-8">
            <div className="flex items-center mb-8">
              <div className="flex flex-col">
                <span className="font-display font-bold text-2xl text-primary">Welcome To</span>
                <span className="font-display text-lg text-primary -mt-1">Artis Symbiose</span>
              </div>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold">Advanced Ophthalmology Platform</h2>
                <p className="text-muted-foreground">
                  The future of eye care technology. Secure, reliable, and built for both patients and healthcare providers.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5 bg-primary/10 p-1.5 rounded-full text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">Secure Authentication</h3>
                    <p className="text-sm text-muted-foreground">Email verification and role-based access control</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5 bg-primary/10 p-1.5 rounded-full text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">NFC Technology</h3>
                    <p className="text-sm text-muted-foreground">Implant verification and medication tracking</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5 bg-primary/10 p-1.5 rounded-full text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">AI-Powered</h3>
                    <p className="text-sm text-muted-foreground">Advanced medical assistance and intelligent analytics</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 max-w-md">
            <Card className="border-primary/10">
              <CardHeader>
                <CardTitle>{isLogin ? "Login" : "Create Account"}</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    type="text"
                    name="username"
                    placeholder="Username"
                    value={formData.username}
                    onChange={handleChange}
                    required
                    disabled={isSubmitting}
                  />
                  <Input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                    disabled={isSubmitting}
                  />
                  {!isLogin && (
                    <>
                      <Input
                        type="text"
                        name="name"
                        placeholder="Full Name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <Input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <Input
                        type="text"
                        name="location"
                        placeholder="Location"
                        value={formData.location}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <Input
                        type="text"
                        name="hospitalName"
                        placeholder="Hospital Name"
                        value={formData.hospitalName}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <Input
                        type="text"
                        name="city"
                        placeholder="City"
                        value={formData.city}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <Input
                        type="text"
                        name="state"
                        placeholder="State"
                        value={formData.state}
                        onChange={handleChange}
                        required
                        disabled={isSubmitting}
                      />
                      <div className="p-3 bg-primary/5 rounded-md">
                        <p className="text-sm">Selected Role: <span className="font-medium capitalize">{selectedRole}</span></p>
                        <button
                          type="button"
                          onClick={() => setSelectedRole(null)}
                          className="text-sm text-primary hover:underline mt-1"
                          disabled={isSubmitting}
                        >
                          Change Role
                        </button>
                      </div>
                    </>
                  )}
                  {error && <p className="text-destructive text-sm">{error}</p>}
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" /> 
                        {isLogin ? "Logging in..." : "Creating account..."}
                      </span>
                    ) : (
                      isLogin ? "Login" : "Register"
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="link"
                    className="w-full"
                    onClick={() => setIsLogin(!isLogin)}
                    disabled={isSubmitting}
                  >
                    {isLogin ? "Need an account? Register" : "Have an account? Login"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}