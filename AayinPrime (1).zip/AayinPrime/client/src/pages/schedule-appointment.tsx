import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MapPin, Clock, Calendar as CalendarIcon, Phone, Navigation } from "lucide-react";
import { format } from "date-fns";

interface Hospital {
  id: number;
  name: string;
  address: string;
  distance: number;
  phone: string;
  specialities: string[];
  rating: number;
  availableSlots: string[];
}

const ScheduleAppointment: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [step, setStep] = useState<'datetime' | 'hospitals' | 'details'>('datetime');
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationPermission, setLocationPermission] = useState<string>('prompt');
  const [appointmentDetails, setAppointmentDetails] = useState({
    reason: '',
    symptoms: '',
    notes: ''
  });

  // Request location permission on component mount
  useEffect(() => {
    requestLocationPermission();
  }, []);

  const requestLocationPermission = async () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location not supported",
        description: "Your browser doesn't support location services",
        variant: "destructive"
      });
      return;
    }

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000
        });
      });

      setUserLocation({
        lat: position.coords.latitude,
        lng: position.coords.longitude
      });
      setLocationPermission('granted');
      
      toast({
        title: "Location Access Granted",
        description: "We'll show you nearby hospitals"
      });
    } catch (error) {
      setLocationPermission('denied');
      toast({
        title: "Location Access Denied",
        description: "We'll show all available hospitals",
        variant: "destructive"
      });
    }
  };

  // Fetch nearby hospitals based on user location
  const { data: hospitals, isLoading: hospitalsLoading } = useQuery({
    queryKey: ['nearby-hospitals', userLocation],
    queryFn: async (): Promise<Hospital[]> => {
      const response = await apiRequest('POST', '/api/hospitals/nearby', {
        location: userLocation,
        date: selectedDate?.toISOString(),
        time: selectedTime
      });
      return response.json();
    },
    enabled: step === 'hospitals' && !!selectedDate && !!selectedTime
  });

  // Create appointment mutation
  const createAppointmentMutation = useMutation({
    mutationFn: async (appointmentData: any) => {
      const response = await apiRequest('POST', '/api/appointments', appointmentData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment Scheduled",
        description: "Your appointment has been successfully scheduled"
      });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      setLocation('/patient-dashboard');
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Schedule",
        description: error.message || "Failed to schedule appointment",
        variant: "destructive"
      });
    }
  });

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  const handleDateTimeNext = () => {
    if (!selectedDate || !selectedTime) {
      toast({
        title: "Missing Information",
        description: "Please select both date and time",
        variant: "destructive"
      });
      return;
    }
    setStep('hospitals');
  };

  const handleHospitalSelect = (hospital: Hospital) => {
    setSelectedHospital(hospital);
    setStep('details');
  };

  const handleSubmitAppointment = () => {
    if (!selectedHospital || !appointmentDetails.reason.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    createAppointmentMutation.mutate({
      hospitalId: selectedHospital.id,
      date: selectedDate?.toISOString(),
      time: selectedTime,
      reason: appointmentDetails.reason,
      symptoms: appointmentDetails.symptoms,
      notes: appointmentDetails.notes,
      status: 'scheduled'
    });
  };

  const renderDateTimeStep = () => (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CalendarIcon className="h-5 w-5" />
          Select Date & Time
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label className="text-sm font-medium mb-3 block">Choose Date</Label>
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            disabled={(date) => date < new Date() || date < new Date("1900-01-01")}
            className="rounded-md border shadow"
          />
        </div>
        
        <div>
          <Label className="text-sm font-medium mb-3 block">Choose Time</Label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {timeSlots.map((time) => (
              <Button
                key={time}
                variant={selectedTime === time ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTime(time)}
                className="w-full"
              >
                {time}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button 
            variant="outline" 
            onClick={() => setLocation('/patient-dashboard')}
            className="flex-1"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <Button onClick={handleDateTimeNext} className="flex-1">
            Next: Find Hospitals
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderHospitalsStep = () => (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Nearby Hospitals
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          {selectedDate && selectedTime && 
            `Appointment for ${format(selectedDate, 'PPP')} at ${selectedTime}`
          }
        </p>
      </CardHeader>
      <CardContent>
        {locationPermission === 'denied' && (
          <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              Location access denied. Showing all available hospitals.
              <Button 
                variant="link" 
                size="sm" 
                onClick={requestLocationPermission}
                className="ml-2 h-auto p-0"
              >
                Enable Location
              </Button>
            </p>
          </div>
        )}

        {hospitalsLoading ? (
          <div className="text-center py-8">Loading nearby hospitals...</div>
        ) : (
          <div className="space-y-4">
            {hospitals?.map((hospital) => (
              <Card 
                key={hospital.id} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleHospitalSelect(hospital)}
              >
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{hospital.name}</h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                        <MapPin className="h-3 w-3" />
                        {hospital.address}
                        {userLocation && (
                          <span className="ml-2">• {hospital.distance.toFixed(1)} km away</span>
                        )}
                      </p>
                      
                      <div className="flex items-center gap-4 mt-3">
                        <div className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          <span className="text-sm">{hospital.phone}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-sm">Rating: {hospital.rating}/5</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1 mt-3">
                        {hospital.specialities.map((spec) => (
                          <Badge key={spec} variant="secondary" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="ml-4">
                      <Badge variant="outline" className="text-green-600">
                        Available
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="flex gap-3 pt-6">
          <Button 
            variant="outline" 
            onClick={() => setStep('datetime')}
            className="flex-1"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderDetailsStep = () => (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Appointment Details</CardTitle>
        <div className="text-sm text-muted-foreground space-y-1">
          <p><strong>{selectedHospital?.name}</strong></p>
          <p>{selectedDate && format(selectedDate, 'PPP')} at {selectedTime}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="reason">Reason for Visit *</Label>
          <Input
            id="reason"
            value={appointmentDetails.reason}
            onChange={(e) => setAppointmentDetails(prev => ({ ...prev, reason: e.target.value }))}
            placeholder="e.g., Eye examination, Follow-up, Vision problems"
            required
          />
        </div>

        <div>
          <Label htmlFor="symptoms">Symptoms (Optional)</Label>
          <Textarea
            id="symptoms"
            value={appointmentDetails.symptoms}
            onChange={(e) => setAppointmentDetails(prev => ({ ...prev, symptoms: e.target.value }))}
            placeholder="Describe any symptoms you're experiencing"
            rows={3}
          />
        </div>

        <div>
          <Label htmlFor="notes">Additional Notes (Optional)</Label>
          <Textarea
            id="notes"
            value={appointmentDetails.notes}
            onChange={(e) => setAppointmentDetails(prev => ({ ...prev, notes: e.target.value }))}
            placeholder="Any additional information for the doctor"
            rows={2}
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button 
            variant="outline" 
            onClick={() => setStep('hospitals')}
            className="flex-1"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <Button 
            onClick={handleSubmitAppointment} 
            className="flex-1"
            disabled={createAppointmentMutation.isPending}
          >
            {createAppointmentMutation.isPending ? 'Scheduling...' : 'Schedule Appointment'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-6xl mx-auto py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Schedule Appointment</h1>
          <p className="text-muted-foreground">Book an appointment with nearby healthcare providers</p>
        </div>

        {step === 'datetime' && renderDateTimeStep()}
        {step === 'hospitals' && renderHospitalsStep()}
        {step === 'details' && renderDetailsStep()}
      </div>
    </div>
  );
};

export default ScheduleAppointment;