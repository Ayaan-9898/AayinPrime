import React from 'react';
import Sidebar from '@/components/dashboard/sidebar';

import MedicationSchedule from '@/components/dashboard/medication-schedule';
import AIAssistant from '@/components/dashboard/ai-assistant';
import FeatureCards from '@/components/dashboard/feature-cards';
import AppointmentTable from '@/components/dashboard/appointment-table';
import { useAuth } from '@/hooks/use-auth';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-light">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between shadow-sm sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-display font-semibold text-gray-800">Dashboard</h1>
            <p className="text-sm text-gray-500">Welcome back, {user?.name || user?.username}</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition relative">
              <span className="material-icons text-gray-600">notifications</span>
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-primary"></span>
            </button>
            
            <div className="relative">
              <button className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 rounded-full py-2 px-4 transition">
                <span className="text-sm font-medium">Quick Actions</span>
                <span className="material-icons text-sm">expand_more</span>
              </button>
            </div>
          </div>
        </header>
        
        {/* Dashboard Content */}
        <div className="p-6">
          {/* Medication & AI Assistant Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Medication Schedule */}
            <MedicationSchedule />
            
            {/* AI Assistant */}
            <AIAssistant />
          </div>
          
          {/* Features Row */}
          <FeatureCards />
          
          {/* Upcoming Appointments */}
          <AppointmentTable />
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
