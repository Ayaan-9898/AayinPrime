import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { User } from '@shared/schema';
import { useLocation } from 'wouter';

const IssueImplantPage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [selectedPatient, setSelectedPatient] = useState<User | null>(null);
  const [implantNumber, setImplantNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Fetch patients for this hospital
  const { data: patients, isLoading: patientsLoading } = useQuery({
    queryKey: ['/api/hospital/patients'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/hospital/patients');
      return res.json();
    }
  });

  // Mutation for issuing implant number
  const issueImplantMutation = useMutation({
    mutationFn: async ({ patientId, implantNumber }: { patientId: number, implantNumber: string }) => {
      const res = await apiRequest('POST', `/api/hospital/issue-implant`, {
        patientId,
        implantVerificationNumber: implantNumber
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/hospital/patients'] });
      toast({
        title: "Implant Issued",
        description: "The implant verification number has been issued successfully.",
      });
      setImplantNumber('');
      setSelectedPatient(null);
    },
    onError: (error: Error) => {
      setError(error.message || "Failed to issue implant number. Please try again.");
      toast({
        title: "Error",
        description: error.message || "Failed to issue implant number",
        variant: "destructive",
      });
    }
  });

  const handleIssueImplant = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    if (!selectedPatient) {
      setError("Please select a patient first");
      setIsSubmitting(false);
      return;
    }

    if (!implantNumber || implantNumber.length < 6) {
      setError("Please enter a valid implant number (at least 6 characters)");
      setIsSubmitting(false);
      return;
    }

    try {
      await issueImplantMutation.mutateAsync({
        patientId: selectedPatient.id,
        implantNumber
      });

      setIsSubmitting(false);
    } catch (err) {
      setIsSubmitting(false);
    }
  };

  const generateRandomImplantNumber = () => {
    // Generate a random implant number format: IMP-XXXX-XXXX
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = 'IMP-';
    for (let i = 0; i < 4; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    result += '-';
    for (let i = 0; i < 4; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setImplantNumber(result);
  };

  const handlePatientSelect = (patient: User) => {
    setSelectedPatient(patient);
  };

  if (user?.role !== 'hospital') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>
              You need hospital access to issue implant verification numbers.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setLocation('/')}>Go Home</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Issue Implant Verification Number</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Patient List */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Select Patient</CardTitle>
              <CardDescription>Choose a patient to issue an implant verification number</CardDescription>
            </CardHeader>
            <CardContent>
              {patientsLoading ? (
                <div className="flex justify-center p-4">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : patients && patients.length > 0 ? (
                <div className="space-y-2">
                  {patients.map((patient: User) => (
                    <Button
                      key={patient.id}
                      variant={selectedPatient?.id === patient.id ? "default" : "outline"}
                      className="w-full justify-start"
                      onClick={() => handlePatientSelect(patient)}
                    >
                      <div className="text-left">
                        <div className="font-medium">{patient.name}</div>
                        <div className="text-xs text-muted-foreground">{patient.email}</div>
                      </div>
                    </Button>
                  ))}
                </div>
              ) : (
                <div className="text-center p-4 text-muted-foreground">
                  No patients found. Add patients first.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Implant Form */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Issue Implant Number</CardTitle>
              <CardDescription>
                {selectedPatient 
                  ? `Issuing implant number for: ${selectedPatient.name}`
                  : "Select a patient first"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleIssueImplant} className="space-y-4">
                {error && (
                  <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm">
                    {error}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="implantNumber">Implant Verification Number</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="implantNumber"
                      value={implantNumber}
                      onChange={(e) => setImplantNumber(e.target.value)}
                      placeholder="Enter implant number"
                      disabled={!selectedPatient || isSubmitting}
                    />
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={generateRandomImplantNumber}
                      disabled={!selectedPatient || isSubmitting}
                    >
                      Generate
                    </Button>
                  </div>
                </div>

                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setLocation('/hospital-dashboard')}
                  >
                    Back to Dashboard
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={!selectedPatient || !implantNumber || isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" /> 
                        Issuing...
                      </span>
                    ) : (
                      "Issue Implant Number"
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Information Card */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>About Implant Verification</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Implant verification numbers are unique identifiers that allow patients to verify and 
                  track their ocular implants. These numbers should be provided to patients before their 
                  surgery or procedure.
                </p>
                <div className="bg-primary/5 p-4 rounded-md">
                  <h3 className="font-medium mb-2">Important Notes:</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Each implant number must be unique</li>
                    <li>The verification number should be recorded in the patient's medical record</li>
                    <li>Patients will need this number to register their implant in the system</li>
                    <li>The implant number is used for medication tracking and reminders</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default IssueImplantPage;