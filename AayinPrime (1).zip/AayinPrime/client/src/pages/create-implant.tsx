
import React, { useState, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { generateRandomString } from '@/lib/utils';

const CreateImplantPage: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    age: '',
    gender: '',
    bloodGroup: '',
    emergencyContact: '',
    medicalHistory: '',
    implantVerificationNumber: ''
  });

  useEffect(() => {
    // Generate implant verification number only when form is submitted
    if (!formData.implantVerificationNumber) {
      setFormData(prev => ({
        ...prev,
        implantVerificationNumber: generateRandomString(12)
      }));
    }
  }, []);

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.age.trim()) newErrors.age = 'Age is required';
    if (!formData.gender.trim()) newErrors.gender = 'Gender is required';
    if (!formData.bloodGroup.trim()) newErrors.bloodGroup = 'Blood group is required';
    if (!formData.emergencyContact.trim()) newErrors.emergencyContact = 'Emergency contact is required';
    if (!formData.medicalHistory.trim()) newErrors.medicalHistory = 'Medical history is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const createPatientMutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch('/api/hospital/create-patient', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error('Failed to create patient');
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Patient created successfully with implant verification number'
      });
      setFormData({
        name: '',
        email: '',
        phone: '',
        location: '',
        age: '',
        gender: '',
        bloodGroup: '',
        emergencyContact: '',
        medicalHistory: '',
        implantVerificationNumber: generateRandomString(12)
      });
      setErrors({});
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to create patient',
        variant: 'destructive'
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      createPatientMutation.mutate(formData);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Create Implant Verification Number</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Patient Name *</label>
          <Input
            name="name"
            value={formData.name}
            onChange={handleChange}
            className={errors.name ? 'border-red-500' : ''}
          />
          {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Email *</label>
          <Input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={errors.email ? 'border-red-500' : ''}
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Phone *</label>
          <Input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className={errors.phone ? 'border-red-500' : ''}
          />
          {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Age *</label>
          <Input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            className={errors.age ? 'border-red-500' : ''}
          />
          {errors.age && <p className="text-red-500 text-sm mt-1">{errors.age}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Gender *</label>
          <select
            name="gender"
            value={formData.gender}
            onChange={handleChange}
            className={`w-full p-2 border rounded-md ${errors.gender ? 'border-red-500' : ''}`}
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
          {errors.gender && <p className="text-red-500 text-sm mt-1">{errors.gender}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Blood Group *</label>
          <Input
            name="bloodGroup"
            value={formData.bloodGroup}
            onChange={handleChange}
            className={errors.bloodGroup ? 'border-red-500' : ''}
          />
          {errors.bloodGroup && <p className="text-red-500 text-sm mt-1">{errors.bloodGroup}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Location *</label>
          <Input
            name="location"
            value={formData.location}
            onChange={handleChange}
            className={errors.location ? 'border-red-500' : ''}
          />
          {errors.location && <p className="text-red-500 text-sm mt-1">{errors.location}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Emergency Contact *</label>
          <Input
            name="emergencyContact"
            value={formData.emergencyContact}
            onChange={handleChange}
            className={errors.emergencyContact ? 'border-red-500' : ''}
          />
          {errors.emergencyContact && <p className="text-red-500 text-sm mt-1">{errors.emergencyContact}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Medical History *</label>
          <textarea
            name="medicalHistory"
            value={formData.medicalHistory}
            onChange={handleChange}
            className={`w-full p-2 border rounded-md min-h-[100px] ${errors.medicalHistory ? 'border-red-500' : ''}`}
          />
          {errors.medicalHistory && <p className="text-red-500 text-sm mt-1">{errors.medicalHistory}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Implant Verification Number</label>
          <Input
            name="implantVerificationNumber"
            value={formData.implantVerificationNumber}
            readOnly
            className="bg-gray-100"
          />
          <p className="text-sm text-gray-500 mt-1">This number is automatically generated</p>
        </div>

        <Button 
          type="submit"
          className="w-full"
          disabled={createPatientMutation.isPending}
        >
          {createPatientMutation.isPending ? 'Creating...' : 'Create Patient'}
        </Button>
      </form>
    </div>
  );
};

export default CreateImplantPage;
