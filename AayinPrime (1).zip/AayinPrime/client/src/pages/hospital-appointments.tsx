import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Calendar, Clock, User, MapPin, Phone, Mail, FileText, Stethoscope } from 'lucide-react';
import { format } from 'date-fns';

interface Appointment {
  id: number;
  userId: number;
  hospitalId: number;
  date: string;
  time: string;
  reason: string;
  symptoms?: string;
  notes?: string;
  status: string;
  patient: {
    name: string;
    email: string;
    phone: string;
  };
}

const HospitalAppointments: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Fetch appointments for this hospital
  const { data: appointments, isLoading } = useQuery<Appointment[]>({
    queryKey: ['hospital-appointments', user?.id],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/hospitals/${user?.id}/appointments`);
      return response.json();
    },
    enabled: !!user?.id
  });

  // Update appointment status mutation
  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ appointmentId, status, notes }: { appointmentId: number; status: string; notes?: string }) => {
      const response = await apiRequest('PUT', `/api/appointments/${appointmentId}`, {
        status,
        hospitalNotes: notes
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment Updated",
        description: "Appointment status has been updated successfully"
      });
      queryClient.invalidateQueries({ queryKey: ['hospital-appointments'] });
      setShowDetails(false);
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update appointment",
        variant: "destructive"
      });
    }
  });

  const filteredAppointments = appointments?.filter(apt => 
    filterStatus === 'all' || apt.status === filterStatus
  ) || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleStatusUpdate = (appointmentId: number, newStatus: string, notes?: string) => {
    updateAppointmentMutation.mutate({ appointmentId, status: newStatus, notes });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 p-4">
        <div className="max-w-6xl mx-auto py-6">
          <div className="text-center">Loading appointments...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-6xl mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Patient Appointments</h1>
            <p className="text-muted-foreground">Manage your scheduled patient appointments</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Hospital</p>
            <p className="font-medium">{user?.hospitalName || user?.name}</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="text-xl font-bold">{appointments?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Scheduled</p>
                  <p className="text-xl font-bold">
                    {appointments?.filter(apt => apt.status === 'scheduled').length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                  <Stethoscope className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Confirmed</p>
                  <p className="text-xl font-bold">
                    {appointments?.filter(apt => apt.status === 'confirmed').length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <User className="h-5 w-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-xl font-bold">
                    {appointments?.filter(apt => apt.status === 'completed').length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter Tabs */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Appointments</CardTitle>
              <div className="flex gap-2">
                {['all', 'scheduled', 'confirmed', 'completed', 'cancelled'].map((status) => (
                  <Button
                    key={status}
                    variant={filterStatus === status ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilterStatus(status)}
                    className="capitalize"
                  >
                    {status}
                  </Button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredAppointments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No appointments found for the selected filter.
              </div>
            ) : (
              <div className="space-y-4">
                {filteredAppointments.map((appointment) => (
                  <Card key={appointment.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <User className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <h3 className="font-semibold">{appointment.patient.name}</h3>
                                <p className="text-sm text-muted-foreground">{appointment.reason}</p>
                              </div>
                            </div>
                            <Badge className={getStatusColor(appointment.status)}>
                              {appointment.status}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              <span>{format(new Date(appointment.date), 'PPP')}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span>{appointment.time}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <span>{appointment.patient.phone}</span>
                            </div>
                          </div>

                          {appointment.symptoms && (
                            <div className="bg-yellow-50 p-3 rounded-lg">
                              <p className="text-sm"><strong>Symptoms:</strong> {appointment.symptoms}</p>
                            </div>
                          )}
                        </div>

                        <div className="ml-4 flex flex-col gap-2">
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedAppointment(appointment);
                              setShowDetails(true);
                            }}
                          >
                            View Details
                          </Button>
                          
                          {appointment.status === 'scheduled' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusUpdate(appointment.id, 'confirmed')}
                              disabled={updateAppointmentMutation.isPending}
                            >
                              Confirm
                            </Button>
                          )}
                          
                          {appointment.status === 'confirmed' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusUpdate(appointment.id, 'completed')}
                              disabled={updateAppointmentMutation.isPending}
                            >
                              Complete
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Appointment Details Dialog */}
        <Dialog open={showDetails} onOpenChange={setShowDetails}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Appointment Details</DialogTitle>
            </DialogHeader>
            
            {selectedAppointment && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Patient Information</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span>{selectedAppointment.patient.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        <span>{selectedAppointment.patient.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        <span>{selectedAppointment.patient.phone}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Appointment Details</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{format(new Date(selectedAppointment.date), 'PPP')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>{selectedAppointment.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        <span>{selectedAppointment.reason}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {selectedAppointment.symptoms && (
                  <div>
                    <h4 className="font-medium mb-2">Symptoms</h4>
                    <p className="text-sm bg-yellow-50 p-3 rounded-lg">{selectedAppointment.symptoms}</p>
                  </div>
                )}

                {selectedAppointment.notes && (
                  <div>
                    <h4 className="font-medium mb-2">Patient Notes</h4>
                    <p className="text-sm bg-blue-50 p-3 rounded-lg">{selectedAppointment.notes}</p>
                  </div>
                )}

                <div className="flex gap-2 pt-4">
                  {selectedAppointment.status === 'scheduled' && (
                    <Button
                      onClick={() => handleStatusUpdate(selectedAppointment.id, 'confirmed')}
                      disabled={updateAppointmentMutation.isPending}
                    >
                      Confirm Appointment
                    </Button>
                  )}
                  
                  {selectedAppointment.status === 'confirmed' && (
                    <Button
                      onClick={() => handleStatusUpdate(selectedAppointment.id, 'completed')}
                      disabled={updateAppointmentMutation.isPending}
                    >
                      Mark Complete
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    onClick={() => handleStatusUpdate(selectedAppointment.id, 'cancelled')}
                    disabled={updateAppointmentMutation.isPending}
                  >
                    Cancel Appointment
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default HospitalAppointments;