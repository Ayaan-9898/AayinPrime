import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import NFCVerification from '@/components/nfc-verification';
import { useAuth } from '@/hooks/use-auth';
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const ImplantVerificationPage: React.FC = () => {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const userRole = localStorage.getItem('userRole');

  // Redirect hospital users directly to dashboard
  useEffect(() => {
    if (userRole === 'hospital') {
      navigate('/dashboard');
    }
  }, [userRole, navigate]);

  // Redirect to dashboard when verified
  useEffect(() => {
    if (user?.implantVerified) {
      navigate('/dashboard');
    }
  }, [user?.implantVerified, navigate]);

  const handleSkip = () => {
    // Mark the user as having skipped implant verification.  This line is kept from the original, as it's a reasonable action.
    localStorage.setItem('skippedImplantVerification', 'true');
    navigate('/dashboard');
  };

  // If user is a hospital, don't render this page
  if (userRole === 'hospital') {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-primary/10 to-background">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl text-center">Implant Verification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-center text-muted-foreground">
            Please verify your implant by scanning the NFC card provided by your hospital, or skip if you don't have an implant yet
          </p>

          <div className="space-y-4">
            <NFCVerification />

            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">
                Don't have an implant card yet?
              </p>
              <Button
                variant="outline"
                onClick={handleSkip}
                className="w-full"
              >
                Skip for now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ImplantVerificationPage;