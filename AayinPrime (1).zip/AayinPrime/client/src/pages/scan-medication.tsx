import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Smartphone, Camera } from 'lucide-react';
import MedicationScanner from '@/components/medication-scanner';
import PrescriptionScanner from '@/components/prescription-scanner';
import { Medication } from '@shared/schema';

const ScanMedicationPage: React.FC = () => {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');
  const [activeTab, setActiveTab] = useState(tabParam === 'camera' ? 'camera' : 'nfc');
  const [recentlyScanned, setRecentlyScanned] = useState<Medication[]>([]);

  const handleMedicationScanned = (medication: Medication) => {
    setRecentlyScanned(prev => [...prev, medication]);
  };
  
  const handleGoToMedications = () => {
    setLocation('/medications');
  };

  return (
    <div className="container mx-auto px-4 pt-6 pb-16 max-w-4xl">
      <Button 
        variant="ghost" 
        onClick={() => setLocation('/dashboard')}
        className="mb-6"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Button>
      
      <h1 className="text-3xl font-bold mb-2">Add Medication</h1>
      <p className="text-muted-foreground mb-8">
        Scan your medications using NFC or prescription label
      </p>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-8">
          <TabsTrigger value="nfc" className="flex items-center gap-2">
            <Smartphone className="h-4 w-4" />
            <span>NFC Scan</span>
          </TabsTrigger>
          <TabsTrigger value="camera" className="flex items-center gap-2">
            <Camera className="h-4 w-4" />
            <span>Camera Scan</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="nfc" className="mt-0">
          <MedicationScanner onMedicationScanned={handleMedicationScanned} />
        </TabsContent>
        
        <TabsContent value="camera" className="mt-0">
          <PrescriptionScanner onMedicationScanned={handleMedicationScanned} />
        </TabsContent>
      </Tabs>

      {recentlyScanned.length > 0 && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Recently Added Medications</CardTitle>
            <CardDescription>
              These medications have been added to your list
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentlyScanned.map((med, index) => (
                <div key={index} className="p-4 border rounded-lg bg-background">
                  <p className="font-medium">{med.name}</p>
                  {med.dosage && <p className="text-sm text-muted-foreground">Dosage: {med.dosage}</p>}
                  <p className="text-sm text-muted-foreground">Schedule: {med.frequency} - {med.time}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="mt-8 flex justify-center">
        <Button onClick={handleGoToMedications} size="lg">
          View All Medications
        </Button>
      </div>
    </div>
  );
};

export default ScanMedicationPage;