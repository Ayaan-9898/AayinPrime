import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import Sidebar from '@/components/dashboard/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Medication } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, Clock, AlertTriangle, CheckCircle2, Smartphone, Camera, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const MedicationsPage: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showReminders, setShowReminders] = useState(false);
  const [, navigate] = useLocation();
  
  // Fetch medications
  const { data: medications, isLoading } = useQuery({
    queryKey: ['/api/medications'],
    queryFn: async () => {
      const res = await fetch('/api/medications');
      if (!res.ok) throw new Error('Failed to fetch medications');
      return res.json();
    }
  });
  
  // Mark medication as taken
  const markAsTakenMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('PUT', `/api/medications/${id}`, { 
        status: 'taken',
        lastTaken: new Date().toISOString()
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/medications'] });
      toast({
        title: "Medication marked as taken",
        description: "Your medication record has been updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update medication",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Set up reminder notification
  const setupReminderMutation = useMutation({
    mutationFn: async (medication: Medication) => {
      // In a real app, this would register a notification with the browser
      // or a service worker, or connect to a native app API
      return medication;
    },
    onSuccess: (medication) => {
      toast({
        title: "Reminder set",
        description: `You'll be notified when it's time to take ${medication.name}`,
      });
    }
  });
  
  const handleSetupReminder = (medication: Medication) => {
    setupReminderMutation.mutate(medication);
    setShowReminders(true);
  };
  
  // Filter medications by status
  const dueMedications = medications?.filter(med => med.status === 'due') || [];
  const upcomingMedications = medications?.filter(med => med.status === 'upcoming') || [];
  const takenMedications = medications?.filter(med => med.status === 'taken') || [];
  
  // Animation variants for list items
  const listVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-light">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between shadow-sm sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-display font-semibold text-gray-800">Medications</h1>
            <p className="text-sm text-gray-500">Manage your medication schedule</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline"
              className="flex items-center"
              onClick={() => setShowReminders(!showReminders)}
            >
              <Clock className="mr-2 h-4 w-4" />
              {showReminders ? "Hide Reminders" : "Show Reminders"}
            </Button>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Medication
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-60 p-0">
                <div className="divide-y">
                  <Button 
                    variant="ghost" 
                    className="flex items-center w-full justify-start p-3 rounded-none"
                    onClick={() => navigate('/scan-medication?tab=nfc')}
                  >
                    <Smartphone className="mr-2 h-5 w-5 text-primary" />
                    <span>NFC Scan</span>
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="flex items-center w-full justify-start p-3 rounded-none"
                    onClick={() => navigate('/scan-medication?tab=camera')}
                  >
                    <Camera className="mr-2 h-5 w-5 text-primary" />
                    <span>Scan Prescription</span>
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </header>
        
        {/* Medications Content */}
        <div className="p-6">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-8">
              {/* Due Medications */}
              {dueMedications.length > 0 && (
                <div className="bg-white rounded-2xl shadow-md overflow-hidden">
                  <div className="p-6 border-b border-gray-100">
                    <h2 className="text-xl font-display font-semibold flex items-center text-primary">
                      <AlertTriangle className="mr-2 h-5 w-5" />
                      Due Now
                    </h2>
                  </div>
                  
                  <motion.div 
                    className="divide-y divide-gray-100"
                    variants={listVariants}
                    initial="hidden"
                    animate="show"
                  >
                    {dueMedications.map(medication => (
                      <motion.div 
                        key={medication.id}
                        className="p-4 flex items-center hover:bg-gray-50"
                        variants={itemVariants}
                      >
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-4">
                          <span className="material-icons text-primary">medication</span>
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium">{medication.name}</h3>
                          <p className="text-sm text-gray-500">{medication.dosage} - {medication.frequency}</p>
                        </div>
                        
                        <div className="text-right mr-4">
                          <p className="font-mono text-sm font-bold text-primary">{medication.time}</p>
                          <p className="text-xs text-primary">Due now</p>
                        </div>
                        
                        <Button 
                          size="sm"
                          className="bg-primary hover:bg-primary/90"
                          onClick={() => markAsTakenMutation.mutate(medication.id)}
                          disabled={markAsTakenMutation.isPending}
                        >
                          {markAsTakenMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Take Now"
                          )}
                        </Button>
                      </motion.div>
                    ))}
                  </motion.div>
                </div>
              )}
              
              {/* Upcoming Medications */}
              {upcomingMedications.length > 0 && (
                <div className="bg-white rounded-2xl shadow-md overflow-hidden">
                  <div className="p-6 border-b border-gray-100">
                    <h2 className="text-xl font-display font-semibold flex items-center text-gray-800">
                      <Clock className="mr-2 h-5 w-5" />
                      Upcoming
                    </h2>
                  </div>
                  
                  <motion.div 
                    className="divide-y divide-gray-100"
                    variants={listVariants}
                    initial="hidden"
                    animate="show"
                  >
                    {upcomingMedications.map(medication => (
                      <motion.div 
                        key={medication.id}
                        className="p-4 flex items-center hover:bg-gray-50"
                        variants={itemVariants}
                      >
                        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                          <span className="material-icons text-gray-500">medication</span>
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium">{medication.name}</h3>
                          <p className="text-sm text-gray-500">{medication.dosage} - {medication.frequency}</p>
                        </div>
                        
                        <div className="text-right mr-4">
                          <p className="font-mono text-sm font-bold">{medication.time}</p>
                          <p className="text-xs text-gray-500">Upcoming</p>
                        </div>
                        
                        <Button 
                          size="sm"
                          variant="outline"
                          onClick={() => handleSetupReminder(medication)}
                        >
                          Set Reminder
                        </Button>
                      </motion.div>
                    ))}
                  </motion.div>
                </div>
              )}
              
              {/* Taken Medications */}
              {takenMedications.length > 0 && (
                <div className="bg-white rounded-2xl shadow-md overflow-hidden">
                  <div className="p-6 border-b border-gray-100">
                    <h2 className="text-xl font-display font-semibold flex items-center text-green-600">
                      <CheckCircle2 className="mr-2 h-5 w-5" />
                      Taken Today
                    </h2>
                  </div>
                  
                  <motion.div 
                    className="divide-y divide-gray-100"
                    variants={listVariants}
                    initial="hidden"
                    animate="show"
                  >
                    {takenMedications.map(medication => (
                      <motion.div 
                        key={medication.id}
                        className="p-4 flex items-center hover:bg-gray-50"
                        variants={itemVariants}
                      >
                        <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                          <span className="material-icons text-green-600">medication</span>
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium">{medication.name}</h3>
                          <p className="text-sm text-gray-500">{medication.dosage} - {medication.frequency}</p>
                        </div>
                        
                        <div className="text-right">
                          <p className="font-mono text-sm font-bold">{medication.time}</p>
                          <p className="text-xs text-green-600">✓ Taken</p>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                </div>
              )}
              
              {/* Show Reminders Modal */}
              {showReminders && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center"
                  onClick={() => setShowReminders(false)}
                >
                  <motion.div 
                    className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg"
                    onClick={e => e.stopPropagation()}
                    initial={{ y: 50 }}
                    animate={{ y: 0 }}
                  >
                    <h2 className="text-xl font-display font-semibold mb-4">Medication Reminders</h2>
                    
                    <div className="space-y-3 mb-6">
                      {medications?.map(medication => (
                        <div key={medication.id} className="flex items-center justify-between p-3 rounded-xl border border-gray-200">
                          <div className="flex items-center">
                            <span className="material-icons text-primary mr-3">alarm</span>
                            <div>
                              <h3 className="font-medium">{medication.name}</h3>
                              <p className="text-sm text-gray-500">{medication.time} - {medication.frequency}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center">
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input type="checkbox" className="sr-only peer" defaultChecked />
                              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/30 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                            </label>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-between">
                      <Button variant="outline" onClick={() => setShowReminders(false)}>
                        Close
                      </Button>
                      <Button className="bg-primary hover:bg-primary/90">
                        Save Settings
                      </Button>
                    </div>
                  </motion.div>
                </motion.div>
              )}
              
              {/* Empty State */}
              {medications?.length === 0 && (
                <div className="flex flex-col items-center justify-center h-64 bg-white rounded-2xl shadow-md p-8">
                  <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                    <span className="material-icons text-gray-400 text-2xl">medication</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-800 mb-2">No medications yet</h3>
                  <p className="text-gray-500 text-center mb-6">
                    Scan your prescription to add medications.
                  </p>
                  <Button 
                    variant="outline" 
                    className="flex items-center"
                    onClick={() => navigate('/scan-medication')}
                  >
                    <span className="material-icons mr-2">document_scanner</span>
                    Scan Prescription
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default MedicationsPage;