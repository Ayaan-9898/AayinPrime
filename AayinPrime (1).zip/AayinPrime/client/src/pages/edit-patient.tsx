
import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';

const EditPatient = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [implantNumber, setImplantNumber] = useState('');
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/hospital/search-patient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ implantNumber })
      });

      const data = await response.json();
      if (data.success) {
        setPatient(data.patient);
        toast({
          title: "Patient found",
          description: "You can now edit patient's medications"
        });
      } else {
        toast({
          title: "Not Found",
          description: "No patient found with this implant number",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to search patient",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Edit Patient</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Search Patient</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="Enter Implant Number Of Patient..."
              value={implantNumber}
              onChange={(e) => setImplantNumber(e.target.value)}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? 'Searching...' : 'Search'}
            </Button>
          </div>
          
          {patient && (
            <div className="mt-6 space-y-4">
              <div>
                <h3 className="font-medium">Patient Details</h3>
                <p>Name: {patient.name}</p>
                <p>Email: {patient.email}</p>
                <p>Phone: {patient.phone}</p>
              </div>
              <Button onClick={() => window.location.href = `/medications/${patient.id}`}>
                Edit Medications
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EditPatient;
