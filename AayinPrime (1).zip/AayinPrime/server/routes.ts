import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { handleAIAssistant } from "./ai";
import { insertMedicationSchema, insertAppointmentSchema, insertHealthMetricSchema, User } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { generateAndSendOTP, verifyOTP, getOTPUserData } from "./email-verification";

async function verifyHospitalLicense(licenseId: string): Promise<boolean> {
  // Accept the special "SKIP-VERIFICATION" as valid to allow hospitals to skip verification
  if (licenseId === "SKIP-VERIFICATION") {
    return true;
  }
  
  // Valid real hospital license IDs for demonstration
  const validLicenseIds = [
    'MH230145AH', // Maharashtra State Medical License
    'DL184072MH', // Delhi Medical Council License  
    'KA156893BG', // Karnataka Medical Council License
    'TN198234CH', // Tamil Nadu Medical Council License
    'GJ145678SU'  // Gujarat Medical Council License
  ];
  
  // Check if the provided license ID is in our valid list
  if (validLicenseIds.includes(licenseId)) {
    return true;
  }
  
  // Sample test license format for demonstration (HSP-xxxx-xxxx or MED-xxxx-xxxx)
  if (licenseId.startsWith('HSP-') || licenseId.startsWith('MED-')) {
    return true;
  }
  
  if (!licenseId || licenseId.length < 10) {
    return false;
  }
  
  // License format validation for Indian medical licenses
  const licenseFormat = /^[A-Z]{2}\d{6}[A-Z]{2}$/;
  if (!licenseFormat.test(licenseId)) {
    return false;
  }

  // Check state code validity
  const stateCode = licenseId.substring(0, 2);
  const validStateCodes = ['MH', 'DL', 'KA', 'TN', 'GJ', 'UP', 'RJ', 'WB', 'AP', 'MP'];
  
  return validStateCodes.includes(stateCode);
}

function generateRandomString(length: number): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}


export async function registerRoutes(app: Express): Promise<Server> {
  // Add CORS headers to allow access from any origin
  app.use((req, res, next) => {
    // Allow specific origins or all origins based on the request
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
    } else {
      res.header("Access-Control-Allow-Origin", "*");
    }
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Credentials", "true");
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });
  
  // Setup authentication routes
  setupAuth(app);

  // Update user endpoint
  app.put("/api/user", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = req.user.id;
      const updateData = req.body;
      
      // Remove sensitive fields
      delete updateData.password;
      delete updateData.role;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user information" });
    }
  });

  // Username Check Endpoint
  app.post("/api/check-username", async (req: Request, res: Response) => {
    const { username } = req.body;
    if (!username) {
      return res.status(400).json({ exists: false, message: "Username is required" });
    }
    
    const user = await storage.getUserByUsername(username);
    return res.json({ exists: !!user });
  });

  // Medications routes
  app.get("/api/medications", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const userId = req.user.id;
    const medications = await storage.getMedications(userId);
    res.json(medications);
  });

  app.post("/api/medications", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const userId = req.user.id;
      const medicationData = insertMedicationSchema.parse({
        ...req.body,
        userId
      });

      const medication = await storage.createMedication(medicationData);
      res.status(201).json(medication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create medication" });
      }
    }
  });

  app.put("/api/medications/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const medicationId = parseInt(req.params.id);
      const medication = await storage.getMedication(medicationId);

      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }

      if (medication.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access to medication" });
      }

      const updatedMedication = await storage.updateMedication(medicationId, req.body);
      res.json(updatedMedication);
    } catch (error) {
      res.status(500).json({ message: "Failed to update medication" });
    }
  });

  app.delete("/api/medications/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const medicationId = parseInt(req.params.id);
      const medication = await storage.getMedication(medicationId);

      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }

      if (medication.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access to medication" });
      }

      await storage.deleteMedication(medicationId);
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });

  // Health Metrics routes
  app.get("/api/health-metrics", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const userId = req.user.id;
    const healthMetrics = await storage.getHealthMetrics(userId);
    res.json(healthMetrics);
  });

  app.post("/api/health-metrics", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const userId = req.user.id;
      const metricData = insertHealthMetricSchema.parse({
        ...req.body,
        userId
      });

      const healthMetric = await storage.createHealthMetric(metricData);
      res.status(201).json(healthMetric);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create health metric" });
      }
    }
  });

  // Appointments routes
  app.get("/api/appointments", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const userId = req.user.id;
    const appointments = await storage.getAppointments(userId);
    res.json(appointments);
  });

  app.post("/api/appointments", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const userId = req.user.id;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId
      });

      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create appointment" });
      }
    }
  });

  // Hospital appointments endpoints
  app.get("/api/hospitals/:hospitalId/appointments", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || req.user.role !== 'hospital') return res.sendStatus(401);

    try {
      const { hospitalId } = req.params;
      
      // Verify the hospital is accessing their own appointments
      if (parseInt(hospitalId) !== req.user.id) {
        return res.sendStatus(403);
      }

      const appointments = await storage.getHospitalAppointments(parseInt(hospitalId));
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching hospital appointments:", error);
      res.status(500).json({ message: "Failed to fetch hospital appointments" });
    }
  });

  app.put("/api/appointments/:appointmentId", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { appointmentId } = req.params;
      const { status, hospitalNotes } = req.body;

      const appointment = await storage.updateAppointment(parseInt(appointmentId), {
        status
      });

      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }

      res.json(appointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  // AI Assistant routes
  app.post("/api/ai/chat", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const userId = req.user.id;
      const { message, conversationId } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await handleAIAssistant(userId, message, conversationId);
      res.json(response);
    } catch (error) {
      console.error("AI assistant error:", error);
      res.status(500).json({ message: "Failed to process AI request" });
    }
  });

  app.get("/api/conversations", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const userId = req.user.id;
    const conversations = await storage.getConversations(userId);
    res.json(conversations);
  });

  app.get("/api/conversations/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const conversationId = parseInt(req.params.id);
      const conversation = await storage.getConversation(conversationId);

      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      if (conversation.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access to conversation" });
      }

      res.json(conversation);
    } catch (error) {
      res.status(500).json({ message: "Failed to get conversation" });
    }
  });

  // Implant verification endpoint
  app.post("/api/verify-implant", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { implantId } = req.body;

      if (!implantId) {
        return res.status(400).json({
          success: false,
          message: "Implant ID is required"
        });
      }

      // Valid implant verification numbers for demonstration
      const validImplantIds = [
        'IMP-2024-001234',
        'IMP-2024-005678',
        'IMP-2023-987654',
        'IMP-2024-111222',
        'IMP-2023-444333'
      ];

      const isValid = validImplantIds.includes(implantId) || 
                     implantId.startsWith('IMP-') && implantId.length >= 10;

      if (isValid) {
        res.json({
          success: true,
          verified: true,
          message: "Implant verified successfully"
        });
      } else {
        res.status(400).json({
          success: false,
          verified: false,
          message: "Invalid implant verification number"
        });
      }
    } catch (error) {
      console.error("Implant verification error:", error);
      res.status(500).json({
        success: false,
        message: "Internal server error during verification"
      });
    }
  });

  // NFC scanning and medication creation endpoint
  app.post("/api/nfc/scan", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // This is a simulated NFC scan endpoint
      // In a real application, this would interact with the Web NFC API
      // and validate against a secure database of authentic medications

      // Process the NFC tag data from the request
      const { nfcData, tagId } = req.body;

      // Generate different medications based on the tagId or a random selection
      // to simulate different medications being scanned
      const ophthalmicMedications = [
        {
          name: "Lumigan Eye Drops",
          manufacturer: "Allergan",
          dosage: "0.01%",
          frequency: "Daily",
          time: "Evening",
          instructions: "Do not touch tip to eye or other surfaces",
          expiryDate: "2026-03-31",
          status: "active",
          batchNumber: "LM2025031A",
          isAuthentic: true,
          manufactureDate: "2024-03-31",
          nfcTagId: tagId || "NFC123456789"
        },
        {
          name: "Combigan Solution",
          manufacturer: "Allergan",
          dosage: "0.2%/0.5%",
          frequency: "Twice daily",
          time: "Morning and evening",
          instructions: "Approximately 12 hours apart",
          expiryDate: "2026-06-30",
          status: "active",
          batchNumber: "CB2024063A",
          isAuthentic: true,
          manufactureDate: "2024-06-30",
          nfcTagId: tagId || "NFC987654321"
        },
        {
          name: "Latanoprost Ophthalmic Solution",
          manufacturer: "Pfizer",
          dosage: "0.005%",
          frequency: "Once daily",
          time: "Evening",
          instructions: "Store in refrigerator until opened",
          expiryDate: "2025-12-15",
          status: "active",
          batchNumber: "LT2023121A",
          isAuthentic: true,
          manufactureDate: "2023-12-15",
          nfcTagId: tagId || "NFC567890123"
        }
      ];

      // Select a medication - either based on tagId or randomly if not provided
      let medicationData;
      if (tagId) {
        // Use the last digit of the tagId to determine which medication to return
        const index = parseInt(tagId.slice(-1)) % ophthalmicMedications.length;
        medicationData = ophthalmicMedications[index];
      } else {
        // Random selection if no tagId provided
        const randomIndex = Math.floor(Math.random() * ophthalmicMedications.length);
        medicationData = ophthalmicMedications[randomIndex];
      }

      // Create medication data for the current user
      const userMedicationData = {
        userId: req.user.id,
        name: medicationData.name,
        dosage: medicationData.dosage,
        frequency: medicationData.frequency,
        time: medicationData.time,
        instructions: medicationData.instructions,
        status: medicationData.status
      };

      // Simulate a delay to mimic a real NFC scan
      setTimeout(() => {
        res.status(200).json({
          success: true,
          message: "NFC medication data retrieved successfully",
          medication: userMedicationData
        });
      }, 1500);
    } catch (error) {
      console.error("NFC scan error:", error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Server error processing NFC data" 
      });
    }
  });

  // Prescription scanner simulation endpoint with image processing
  app.post("/api/prescription/scan", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Process the image data from the request
      const { image } = req.body;

      if (!image) {
        return res.status(400).json({ 
          success: false, 
          message: "No image data provided" 
        });
      }

      // In a real application, this would:
      // 1. Decode the base64 image
      // 2. Process with OCR/ML to extract medication information
      // 3. Validate the extracted data against a database

      // For demonstration, we'll simulate the OCR process with common ophthalmic medications
      // In a real system, these would be extracted from the image

      // Generate hash from a portion of the image to simulate different medications being recognized
      const imageHash = image.substring(0, 100).split('').reduce((acc: number, char: string) => acc + char.charCodeAt(0), 0);

      const ophthalmicMedications = [
        {
          name: "Xalatan Eye Drops",
          dosage: "0.005%",
          frequency: "Once daily",
          time: "Evening",
          instructions: "Refrigerate unopened bottle",
          status: "active",
          userId: req.user.id
        },
        {
          name: "Timolol Maleate Solution",
          dosage: "0.5%",
          frequency: "Twice daily",
          time: "Morning and evening",
          instructions: "Approximately 12 hours apart",
          status: "active",
          userId: req.user.id
        },
        {
          name: "Prednisolone Acetate Suspension",
          dosage: "1%",
          frequency: "2-4 times daily",
          time: "Evenly spaced",
          instructions: "Shake well before using",
          status: "active",
          userId: req.user.id
        },
        {
          name: "Azopt Suspension",
          dosage: "1%",
          frequency: "Three times daily",
          time: "Morning, afternoon, evening",
          instructions: "Shake well before using",
          status: "active",
          userId: req.user.id
        }
      ];

      // Select a medication based on the imageHash
      const index = imageHash % ophthalmicMedications.length;
      const medicationData = ophthalmicMedications[index];

      // Add prescription source information
      const prescriptionInfo = {
        doctor: "Dr. Sarah Johnson",
        clinic: "Vision Care Center",
        date: new Date().toISOString().split('T')[0],
        patientName: req.user.name || "Patient",
        prescriptionId: `RX${Date.now().toString().slice(-8)}`
      };

      // Simulate processing delay for realism
      setTimeout(() => {
        res.status(200).json({
          success: true,
          message: "Prescription successfully processed",
          medication: medicationData,
          prescription: prescriptionInfo
        });
      }, 2000);

    } catch (error) {
      console.error("Prescription scan error:", error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Server error processing prescription image" 
      });
    }
  });

  // Hospital specific routes
  app.get("/api/hospital/patients", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || req.user.role !== 'hospital') {
      return res.sendStatus(401);
    }

    const hospital = req.user;
    // Use the existing getPatientsByHospital method
    const patients = await storage.getPatientsByHospital(hospital.id);
    res.json(patients);
  });

  app.post("/api/hospital/patient/:id/medication", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || req.user.role !== 'hospital') {
      return res.sendStatus(401);
    }

    const { id } = req.params;
    const { 
      implantVerificationNumber, 
      name, 
      dosage, 
      frequency, 
      time, 
      instructions,
      status = 'active'
    } = req.body;

    try {
      // Verify implant number
      const patient = await storage.getUser(parseInt(id));
      if (!patient || patient.implantVerificationNumber !== implantVerificationNumber) {
        return res.status(400).json({ message: "Invalid implant verification number" });
      }

      // Create the medication for this patient
      const medication = await storage.createMedication({
        userId: parseInt(id),
        name,
        dosage,
        frequency,
        time: time || '',
        instructions: instructions || '',
        status
      });

      // Send a notification to the patient (in a real app, this would use a notification service)
      console.log(`Medication update notification sent to patient ${patient.name}`);

      res.status(201).json(medication);
    } catch (error) {
      console.error("Error adding medication:", error);
      res.status(500).json({ message: "Failed to add medication" });
    }
  });

  // License verification endpoint - accessible without authentication
  // This endpoint is used during the registration process
  app.post("/api/hospital/verify-license", async (req: Request, res: Response) => {
    const { licenseId } = req.body;
    
    // Special case for skipping verification
    if (licenseId === "SKIP-VERIFICATION") {
      return res.json({ 
        verified: true,
        message: "Verification skipped. Limited access granted." 
      });
    }
    
    // Implement license verification logic here
    // This would typically involve checking against a government database
    const isVerified = await verifyHospitalLicense(licenseId);

    if (isVerified) {
      res.json({ 
        verified: true,
        message: "License successfully verified"
      });
    } else {
      res.status(400).json({ 
        message: "Invalid license. If you don't have a license ID, use 'SKIP-VERIFICATION' to continue with limited access." 
      });
    }
  });

  app.post("/api/hospital/create-patient", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || req.user.role !== 'hospital') {
      return res.sendStatus(401);
    }

    try {
      const { name, email, phone, location, implantVerificationNumber } = req.body;
      const hospitalId = req.user.id;
      
      // In a real app, this would send an email invitation
      // For our demo, we'll just log it
      console.log(`Would send invitation email to: ${email}`);
      console.log(`Registration link: ${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co/auth?email=${email}&name=${name}&phone=${phone}&location=${location}`);
      
      if (storage.sendEmail) {
        try {
          await storage.sendEmail({
            to: email,
            subject: "Hospital Registration Invitation",
            text: `You have been invited to register as a patient. Please click the link below to complete your registration:\n\n${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co/auth?email=${email}&name=${name}&phone=${phone}&location=${location}`,
            html: `<p>You have been invited to register as a patient. Please click the link below to complete your registration:</p>
                   <a href="${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co/auth?email=${email}&name=${name}&phone=${phone}&location=${location}">Complete Registration</a>`
          });
        } catch (error) {
          console.error("Failed to send email invitation:", error);
          // Continue even if email fails
        }
      }

      const newUser = await storage.createUser({
        username: email,
        password: generateRandomString(12), // Generate a random initial password
        role: 'patient',
        name,
        email,
        phone,
        location,
        implantVerificationNumber,
        hospitalId
      });

      res.status(201).json(newUser);
    } catch (error) {
      console.error('Create patient error:', error);
      res.status(500).json({ message: 'Failed to create patient' });
    }
  });

  app.post("/api/hospital/search-patient", async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || req.user.role !== 'hospital') {
    return res.sendStatus(401);
  }

  try {
    const { implantNumber } = req.body;
    if (!implantNumber) {
      return res.status(400).json({ success: false, message: "Implant number is required" });
    }

    // Get all patients for this hospital
    const patients = await storage.getPatientsByHospital(req.user.id);

    // Find the patient with the matching implant number
    const patient = patients.find((patient: User) => patient.implantVerificationNumber === implantNumber);

    if (patient) {
      res.json({ success: true, patient });
    } else {
      res.status(404).json({ success: false, message: "Patient not found" });
    }
  } catch (error) {
    console.error("Patient search error:", error);
    res.status(500).json({ success: false, message: "Failed to search patient" });
  }
});

  // Nearby hospitals search endpoint
  app.post("/api/hospitals/nearby", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { location, date, time } = req.body;
      
      // Get all hospitals from database
      const allHospitals = await storage.getHospitals();
      
      // Calculate distances and add mock data for demonstration
      const hospitalsWithDetails = allHospitals.map((hospital, index) => {
        // Calculate distance if user location is provided
        let distance = Math.random() * 10 + 1; // Random distance between 1-11 km
        if (location) {
          // In a real app, you'd use a proper distance calculation
          distance = Math.sqrt(
            Math.pow(location.lat - (28.6139 + index * 0.01), 2) + 
            Math.pow(location.lng - (77.2090 + index * 0.01), 2)
          ) * 111; // Rough conversion to km
        }

        return {
          id: hospital.id,
          name: hospital.hospitalName || hospital.name || `Medical Center ${index + 1}`,
          address: hospital.location || `Address ${index + 1}`,
          distance: Math.round(distance * 10) / 10,
          phone: hospital.phone || `+91-${Math.floor(Math.random() * 9000000000) + 1000000000}`,
          specialities: ['Ophthalmology', 'General Medicine', 'Surgery', 'Cardiology'].slice(0, Math.floor(Math.random() * 3) + 2),
          rating: Math.round((Math.random() * 2 + 3) * 10) / 10, // Rating between 3.0-5.0
          availableSlots: ['09:00', '10:30', '14:00', '15:30', '16:00']
        };
      });

      // Sort by distance if location provided
      if (location) {
        hospitalsWithDetails.sort((a, b) => a.distance - b.distance);
      }

      res.json(hospitalsWithDetails);
    } catch (error) {
      console.error("Error fetching nearby hospitals:", error);
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

app.post("/api/hospital/discharge-card", async (req: Request, res: Response) => {
  if (!req.isAuthenticated() || req.user.role !== 'hospital') {
    return res.sendStatus(401);
  }

  try {
    const { implantNumber, medications } = req.body;
    
    // Validate the implant number and medications
    if (!implantNumber || !medications || !Array.isArray(medications)) {
      return res.status(400).json({ message: "Invalid discharge card data" });
    }

    // Store the discharge card data
    const dischargeData = {
      implantNumber,
      medications,
      hospitalId: req.user.id,
      createdAt: new Date().toISOString()
    };

    // In a real implementation, you would write this to the NFC card
    // For now, we'll just return success
    res.json({
      success: true,
      message: "Discharge card written successfully",
      data: dischargeData
    });
  } catch (error) {
    console.error('Discharge card error:', error);
    res.status(500).json({ message: 'Failed to write discharge card' });
  }
});

app.post("/api/hospital/issue-implant", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || req.user.role !== 'hospital') {
      return res.sendStatus(401);
    }

    try {
      const { patientId, implantVerificationNumber } = req.body;
      const hospitalId = req.user.id;

      // Find the patient
      const patient = await storage.getUser(patientId);
      
      if (!patient) {
        return res.status(404).json({ message: 'Patient not found' });
      }
      
      // Verify the patient belongs to this hospital
      if (patient.hospitalId !== hospitalId) {
        return res.status(403).json({ message: 'You are not authorized to issue implants to this patient' });
      }
      
      // Update the patient with the new implant verification number
      const updatedPatient = await storage.updateUser(patientId, {
        implantVerificationNumber,
        isVerified: false // Reset verification status as this is a new implant
      });
      
      res.json({
        success: true,
        patient: updatedPatient,
        message: 'Implant verification number issued successfully'
      });
    } catch (error) {
      console.error('Issue implant error:', error);
      res.status(500).json({ message: 'Failed to issue implant verification number' });
    }
  });

  // No need to add a register route here - it's already defined in auth.ts

  const DOCTOR_SYSTEM_PROMPT = `You are an AI ophthalmologist assistant specializing in eye implants and post-operative care. 
Your role is to help answer questions about eye health, medical terminology related to ophthalmology, 
and general eye care with a focus on implant-related queries. Always be professional, accurate, and empathetic. 
Remind users to consult their healthcare provider for specific medical advice. You should:
1. Focus on eye implant-related questions and post-operative care
2. Explain medical terms in simple language
3. Provide general guidance about eye health
4. Always emphasize the importance of following their doctor's specific instructions
5. Be clear about emergency situations that require immediate medical attention 
while maintaining medical accuracy.`;

  // Add AI doctor route handler
  app.post('/api/ai/doctor', async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401); // Add authentication check
    try {
      const { message } = req.body;
      const response = await handleAIAssistant(req.user.id, message, undefined, DOCTOR_SYSTEM_PROMPT);
      res.json(response);
    } catch (error) {
      console.error('AI Doctor error:', error);
      res.status(500).json({ error: 'Failed to process AI request' });
    }
  });


  const httpServer = createServer(app);
  return httpServer;
}