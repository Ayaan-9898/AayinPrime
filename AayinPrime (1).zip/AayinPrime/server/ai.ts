import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || (() => {
    throw new Error("OPENAI_API_KEY environment variable is required");
  })()
});

export async function handleAIAssistant(userId: number, message: string, conversationId?: number, customSystemPrompt?: string) {
  let conversation;
  let messages = [];
  
  // Get or create conversation
  if (conversationId) {
    conversation = await storage.getConversation(conversationId);
    if (conversation && conversation.userId !== userId) {
      throw new Error("Unauthorized access to conversation");
    }
  }
  
  if (!conversation) {
    // Create a new conversation with system prompt 
    messages = [
      {
        role: "system",
        content: customSystemPrompt || `You are ArtisAssist, an advanced AI health assistant for Artis Symbiose, a comprehensive ophthalmology and healthcare platform. 

        Your capabilities include:
        - Eye health and vision care guidance
        - Medication information and scheduling help
        - General health and wellness advice
        - Symptom assessment and triage
        - Medical procedure explanations
        - Health condition education
        - Emergency guidance
        - Preventive care recommendations

        Guidelines:
        - Answer ALL health-related questions comprehensively
        - Be empathetic, accurate, and helpful
        - For serious symptoms, recommend immediate medical attention
        - For medication questions, provide information but remind users to consult their doctor
        - Explain medical terms in simple language
        - Provide actionable advice when appropriate
        - If unsure, recommend consulting a healthcare professional
        - Keep responses informative yet concise
        - Be supportive and encouraging

        You can discuss any health topic including but not limited to: eye conditions, medications, symptoms, treatments, procedures, anatomy, nutrition, exercise, mental health, and emergency situations.`
      },
      { role: "user", content: message }
    ];
    
    conversation = await storage.createConversation({
      userId,
      messages
    });
  } else {
    // Add the new message to the existing conversation
    if (conversation.messages && Array.isArray(conversation.messages)) {
      messages = [
        ...conversation.messages,
        { role: "user", content: message }
      ];
    } else {
      // Handle case where messages might not be properly initialized
      messages = [
        {
          role: "system",
          content: customSystemPrompt || `You are an AI health assistant for Artis Symbiose.`
        },
        { role: "user", content: message }
      ];
    }
  }
  
  try {
    // Get health metrics to provide context for the AI
    const healthMetrics = await storage.getHealthMetrics(userId);
    const medications = await storage.getMedications(userId);
    
    // Add context information for the AI
    const contextMessage = {
      role: "system",
      content: `Current patient data: 
      ${healthMetrics.length > 0 ? `Health Metrics: ${JSON.stringify(healthMetrics.slice(-4))}` : 'No health metrics available.'}
      ${medications.length > 0 ? `Medications: ${JSON.stringify(medications)}` : 'No medications available.'}`
    };
    
    // Create message array for the OpenAI request
    const aiMessages = [
      ...messages.filter(m => m.role !== "context"),
      contextMessage
    ];
    
    // Call OpenAI API
    const formattedMessages = aiMessages.map(msg => ({
      role: msg.role as "system" | "user" | "assistant",
      content: msg.content || ""
    }));

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: formattedMessages,
      max_tokens: 500,
    });
    
    // Get the AI response
    const aiResponse = response.choices[0].message.content;
    
    // Update the conversation with the AI response
    const updatedMessages = [
      ...messages,
      { role: "assistant", content: aiResponse }
    ];
    
    // Save the updated conversation
    const updatedConversation = await storage.updateConversation(conversation.id, updatedMessages);
    
    return {
      message: aiResponse,
      conversation: updatedConversation
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to process AI request");
  }
}
