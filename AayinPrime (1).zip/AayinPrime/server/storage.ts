import { users, User, InsertUser, medications, Medication, InsertMedication, healthMetrics, HealthMetric, InsertHealthMetric, appointments, Appointment, InsertAppointment, conversations, Conversation, InsertConversation } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import { db } from "./db";
import { eq } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);

// Define the data file path for persistence
const DATA_DIR = path.join(process.cwd(), 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const MEDICATIONS_FILE = path.join(DATA_DIR, 'medications.json');
const HEALTH_METRICS_FILE = path.join(DATA_DIR, 'health_metrics.json');
const APPOINTMENTS_FILE = path.join(DATA_DIR, 'appointments.json');
const CONVERSATIONS_FILE = path.join(DATA_DIR, 'conversations.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Configure email transport
const emailTransporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER || '',
    pass: process.env.EMAIL_PASSWORD || '',
  },
});

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getPatientsByHospital(hospitalId: number): Promise<User[]>;
  getHospitals(): Promise<User[]>;
  
  // Medication operations
  getMedications(userId: number): Promise<Medication[]>;
  getMedication(id: number): Promise<Medication | undefined>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: number, medication: Partial<Medication>): Promise<Medication | undefined>;
  deleteMedication(id: number): Promise<boolean>;
  
  // Health metrics operations
  getHealthMetrics(userId: number): Promise<HealthMetric[]>;
  getHealthMetricsByType(userId: number, type: string): Promise<HealthMetric[]>;
  createHealthMetric(metric: InsertHealthMetric): Promise<HealthMetric>;
  
  // Appointment operations
  getAppointments(userId: number): Promise<Appointment[]>;
  getHospitalAppointments(hospitalId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<Appointment>): Promise<Appointment | undefined>;
  
  // Conversation operations
  getConversations(userId: number): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: number, messages: {role: string, content: string}[]): Promise<Conversation | undefined>;
  
  // Notification and email functions
  sendLoginNotification(user: User): Promise<void>;
  sendRegistrationNotification(user: User): Promise<void>;
  sendEmail?(options: { to: string, subject: string, text: string, html: string }): Promise<void>;
  
  // Session store
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private medications: Map<number, Medication>;
  private healthMetrics: Map<number, HealthMetric>;
  private appointments: Map<number, Appointment>;
  private conversations: Map<number, Conversation>;
  
  sessionStore: any;
  
  private userCurrentId: number;
  private medicationCurrentId: number;
  private healthMetricCurrentId: number;
  private appointmentCurrentId: number;
  private conversationCurrentId: number;

  constructor() {
    this.users = new Map();
    this.medications = new Map();
    this.healthMetrics = new Map();
    this.appointments = new Map();
    this.conversations = new Map();
    
    this.userCurrentId = 1;
    this.medicationCurrentId = 1;
    this.healthMetricCurrentId = 1;
    this.appointmentCurrentId = 1;
    this.conversationCurrentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24h
    });
    
    // Load data from files if they exist
    this.loadData();
    
    // Add some default health metrics for demonstration
    this.initializeDemoData();
  }
  
  // Load data from files
  private loadData() {
    try {
      if (fs.existsSync(USERS_FILE)) {
        const userData = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        this.users = new Map(userData.map((user: User) => [user.id, user]));
        this.userCurrentId = Math.max(...Array.from(this.users.keys()), 0) + 1;
      }
      
      if (fs.existsSync(MEDICATIONS_FILE)) {
        const medicationData = JSON.parse(fs.readFileSync(MEDICATIONS_FILE, 'utf8'));
        this.medications = new Map(medicationData.map((med: Medication) => [med.id, med]));
        this.medicationCurrentId = Math.max(...Array.from(this.medications.keys()), 0) + 1;
      }
      
      if (fs.existsSync(HEALTH_METRICS_FILE)) {
        const metricsData = JSON.parse(fs.readFileSync(HEALTH_METRICS_FILE, 'utf8'));
        this.healthMetrics = new Map(metricsData.map((metric: HealthMetric) => [metric.id, metric]));
        this.healthMetricCurrentId = Math.max(...Array.from(this.healthMetrics.keys()), 0) + 1;
      }
      
      if (fs.existsSync(APPOINTMENTS_FILE)) {
        const appointmentData = JSON.parse(fs.readFileSync(APPOINTMENTS_FILE, 'utf8'));
        this.appointments = new Map(appointmentData.map((appt: Appointment) => [appt.id, appt]));
        this.appointmentCurrentId = Math.max(...Array.from(this.appointments.keys()), 0) + 1;
      }
      
      if (fs.existsSync(CONVERSATIONS_FILE)) {
        const conversationData = JSON.parse(fs.readFileSync(CONVERSATIONS_FILE, 'utf8'));
        this.conversations = new Map(conversationData.map((conv: Conversation) => [conv.id, conv]));
        this.conversationCurrentId = Math.max(...Array.from(this.conversations.keys()), 0) + 1;
      }
    } catch (error) {
      console.error('Error loading data from files:', error);
    }
  }
  
  // Save data to files
  private saveData() {
    try {
      fs.writeFileSync(USERS_FILE, JSON.stringify(Array.from(this.users.values())));
      fs.writeFileSync(MEDICATIONS_FILE, JSON.stringify(Array.from(this.medications.values())));
      fs.writeFileSync(HEALTH_METRICS_FILE, JSON.stringify(Array.from(this.healthMetrics.values())));
      fs.writeFileSync(APPOINTMENTS_FILE, JSON.stringify(Array.from(this.appointments.values())));
      fs.writeFileSync(CONVERSATIONS_FILE, JSON.stringify(Array.from(this.conversations.values())));
    } catch (error) {
      console.error('Error saving data to files:', error);
    }
  }
  
  // Send email notification
  private async sendEmailNotification(to: string, subject: string, html: string) {
    // In development mode, just log the email content
    console.log(`Email would be sent to ${to} with subject: ${subject}`);
    
    // Skip actual email sending in development mode
    if (process.env.NODE_ENV !== 'production') {
      console.log('Development mode: Skipping actual email send');
      return;
    }
    
    try {
      if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
        console.log('Email credentials not configured. Skipping email notification.');
        return;
      }
      
      // Only try to send if we have valid credentials
      try {
        await emailTransporter.sendMail({
          from: `"Artis Symbiose" <${process.env.EMAIL_USER}>`,
          to,
          subject,
          html,
        });
        console.log(`Email notification sent to ${to}`);
      } catch (emailError) {
        console.error('Error sending email notification, ignoring error:', emailError);
        // We're intentionally swallowing the error here to prevent it from affecting the application flow
      }
    } catch (error) {
      console.error('Error in email notification process:', error);
      // We don't throw here - email failures shouldn't break the app
    }
  }
  
  // Reset all data in the storage
  resetAllData() {
    this.users.clear();
    this.medications.clear();
    this.healthMetrics.clear();
    this.appointments.clear();
    this.conversations.clear();
    
    this.userCurrentId = 1;
    this.medicationCurrentId = 1;
    this.healthMetricCurrentId = 1;
    this.appointmentCurrentId = 1;
    this.conversationCurrentId = 1;
  }
  
  private initializeDemoData() {
    // This will only be used once a user is created
    // and will be linked to their userId
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // Make case-insensitive search
    const lowercaseUsername = username.toLowerCase();
    return Array.from(this.users.values()).find(
      (user) => (user.username || '').toLowerCase() === lowercaseUsername,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    // Make case-insensitive search
    if (!email) return undefined;
    
    const lowercaseEmail = email.toLowerCase();
    return Array.from(this.users.values()).find(
      (user) => user.email && user.email.toLowerCase() === lowercaseEmail,
    );
  }
  
  async getPatientsByHospital(hospitalId: number): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === 'patient' && user.hospitalId === hospitalId
    );
  }

  async getHospitals(): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === 'hospital'
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    
    // Safely extract properties from insertUser with proper typing
    const { 
      username = '', 
      password = '', 
      role = 'patient',
      name = null,
      email = null,
      phone = null,
      location = null,
      isVerified = false,
      specialty = null,
      // Add other properties as needed with safe defaults
      implantVerificationNumber = null,
      hospitalId = null,
      licenseId = null
    } = insertUser as any; // Cast to any to prevent type errors
    
    const user: User = {
      id,
      username,
      password,
      role,
      createdAt: now,
      name,
      email,
      phone,
      location,
      implantVerificationId: null,
      patientHospitalId: null,
      implantVerified: false,
      hospitalName: null,
      hospitalAddress: null,
      hospitalState: null,
      licenseId,
      licenseVerified: false,
      implantVerificationNumber,
      hospitalId,
      isVerified,
      lastLogin: null,
      specialty,
      profileImageUrl: null,
      bio: null,
      preferences: null,
    };
    
    this.users.set(id, user);
    
    // Save to persistent storage
    this.saveData();
    
    // Send registration notification
    await this.sendRegistrationNotification(user);
    
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    
    // Save to persistent storage
    this.saveData();
    
    return updatedUser;
  }
  
  // Email sending function
  async sendEmail(options: { to: string, subject: string, text: string, html: string }): Promise<void> {
    // In development mode, just log the email content
    console.log(`Email would be sent to ${options.to} with subject: ${options.subject}`);
    console.log(`Email content: ${options.text || options.html}`);
    
    // Skip actual email sending in development mode
    if (process.env.NODE_ENV !== 'production') {
      console.log('Development mode: Skipping actual email send');
      return;
    }
    
    try {
      if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
        console.log('Email credentials not configured. Skipping email sending.');
        return;
      }
      
      await emailTransporter.sendMail({
        from: `"Artis Symbiose" <${process.env.EMAIL_USER}>`,
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
      });
    } catch (error) {
      console.error('Error sending email:', error);
      // We don't throw here - email failures shouldn't break the app
    }
  }
  
  // Email notification functions
  async sendLoginNotification(user: User): Promise<void> {
    if (!user.email) return;
    
    const notificationEmail = 'inlife.indore36@gmail.com';
    const subject = 'New Login - Artis Symbiose';
    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #000e21; color: #ffffff; border-radius: 10px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #4d9fff; margin: 0;">Artis Symbiose</h1>
          <p style="margin: 5px 0 0 0; color: #a0aec0;">Advanced Ophthalmology Platform</p>
        </div>
        <h2 style="color: #4d9fff; margin-top: 30px;">New Login Detected</h2>
        <p>A user has just logged into the Artis Symbiose application. Below are the login details:</p>
        <div style="background-color: #001a3a; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #4d9fff;">
          <p><strong style="color: #4d9fff;">Username:</strong> <span style="color: #fff;">${user.username}</span></p>
          <p><strong style="color: #4d9fff;">Role:</strong> <span style="color: #fff;">${user.role}</span></p>
          <p><strong style="color: #4d9fff;">Time:</strong> <span style="color: #fff;">${new Date().toLocaleString()}</span></p>
          ${user.email ? `<p><strong style="color: #4d9fff;">Email:</strong> <span style="color: #fff;">${user.email}</span></p>` : ''}
          ${user.phone ? `<p><strong style="color: #4d9fff;">Phone:</strong> <span style="color: #fff;">${user.phone}</span></p>` : ''}
        </div>
        <div style="margin-top: 30px; padding: 15px; border-left: 3px solid #4d9fff; background-color: #001a3a;">
          <p style="margin: 0 0 10px 0; color: #a0aec0;">If this login was unauthorized, please take immediate action:</p>
          <ol style="color: #a0aec0; margin-top: 0;">
            <li>Change the account password</li>
            <li>Review account activity</li>
            <li>Contact administrator if suspicious activity is detected</li>
          </ol>
        </div>
        <p style="margin-top: 30px; font-size: 12px; color: #718096; text-align: center;">This is an automated notification from the Artis Symbiose system.</p>
      </div>
    `;
    
    await this.sendEmailNotification(notificationEmail, subject, html);
  }
  
  async sendRegistrationNotification(user: User): Promise<void> {
    if (!user.email) return;
    
    const notificationEmail = 'inlife.indore36@gmail.com';
    const subject = 'New User Registration - Artis Symbiose';
    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #000e21; color: #ffffff; border-radius: 10px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #4d9fff; margin: 0;">Artis Symbiose</h1>
          <p style="margin: 5px 0 0 0; color: #a0aec0;">Advanced Ophthalmology Platform</p>
        </div>
        <h2 style="color: #4d9fff; margin-top: 30px;">New User Registration</h2>
        <p>A new user has just registered on the Artis Symbiose platform. Here are the registration details:</p>
        <div style="background-color: #001a3a; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #4d9fff;">
          <p><strong style="color: #4d9fff;">Username:</strong> <span style="color: #fff;">${user.username}</span></p>
          <p><strong style="color: #4d9fff;">Role:</strong> <span style="color: #fff;">${user.role}</span></p>
          <p><strong style="color: #4d9fff;">Registration Time:</strong> <span style="color: #fff;">${new Date().toLocaleString()}</span></p>
          ${user.email ? `<p><strong style="color: #4d9fff;">Email:</strong> <span style="color: #fff;">${user.email}</span></p>` : ''}
          ${user.phone ? `<p><strong style="color: #4d9fff;">Phone:</strong> <span style="color: #fff;">${user.phone}</span></p>` : ''}
          ${user.name ? `<p><strong style="color: #4d9fff;">Name:</strong> <span style="color: #fff;">${user.name}</span></p>` : ''}
          ${user.location ? `<p><strong style="color: #4d9fff;">Location:</strong> <span style="color: #fff;">${user.location}</span></p>` : ''}
          <p><strong style="color: #4d9fff;">Verification Status:</strong> <span style="color: ${user.isVerified ? '#5cca8a' : '#e63946'};">${user.isVerified ? 'Verified' : 'Pending Verification'}</span></p>
        </div>
        <div style="margin-top: 30px; padding: 15px; border-left: 3px solid #4d9fff; background-color: #001a3a;">
          <p style="margin: 0; color: #a0aec0;">User account has been created and ${user.isVerified ? 'is verified' : 'is awaiting email verification'}.</p>
        </div>
        <p style="margin-top: 30px; font-size: 12px; color: #718096; text-align: center;">This is an automated notification from the Artis Symbiose system.</p>
      </div>
    `;
    
    await this.sendEmailNotification(notificationEmail, subject, html);
  }
  
  // Medication operations
  async getMedications(userId: number): Promise<Medication[]> {
    return Array.from(this.medications.values()).filter(
      (medication) => medication.userId === userId
    );
  }
  
  async getMedication(id: number): Promise<Medication | undefined> {
    return this.medications.get(id);
  }
  
  async createMedication(medication: InsertMedication): Promise<Medication> {
    const id = this.medicationCurrentId++;
    const newMedication: Medication = {
      id,
      userId: medication.userId,
      name: medication.name,
      dosage: medication.dosage,
      frequency: medication.frequency,
      time: medication.time,
      status: medication.status || null,
      instructions: medication.instructions || null,
      expiryDate: null, // Will be filled separately when needed
    };
    this.medications.set(id, newMedication);
    
    // Save to persistent storage
    this.saveData();
    
    return newMedication;
  }
  
  async updateMedication(id: number, medicationData: Partial<Medication>): Promise<Medication | undefined> {
    const medication = this.medications.get(id);
    if (!medication) return undefined;
    
    const updatedMedication = { ...medication, ...medicationData };
    this.medications.set(id, updatedMedication);
    
    // Save to persistent storage
    this.saveData();
    
    return updatedMedication;
  }
  
  async deleteMedication(id: number): Promise<boolean> {
    const result = this.medications.delete(id);
    
    // Save to persistent storage
    if (result) {
      this.saveData();
    }
    
    return result;
  }
  
  // Health metrics operations
  async getHealthMetrics(userId: number): Promise<HealthMetric[]> {
    return Array.from(this.healthMetrics.values()).filter(
      (metric) => metric.userId === userId
    );
  }
  
  async getHealthMetricsByType(userId: number, type: string): Promise<HealthMetric[]> {
    return Array.from(this.healthMetrics.values()).filter(
      (metric) => metric.userId === userId && metric.type === type
    );
  }
  
  async createHealthMetric(metric: InsertHealthMetric): Promise<HealthMetric> {
    const id = this.healthMetricCurrentId++;
    const now = new Date();
    const newMetric: HealthMetric = {
      ...metric,
      id,
      timestamp: now,
      status: metric.status || null,
      unit: metric.unit || null
    };
    this.healthMetrics.set(id, newMetric);
    
    // Save to persistent storage
    this.saveData();
    
    return newMetric;
  }
  
  // Appointment operations
  async getAppointments(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId
    );
  }

  async getHospitalAppointments(hospitalId: number): Promise<any[]> {
    const hospitalAppointments = Array.from(this.appointments.values())
      .filter(appointment => appointment.hospitalId === hospitalId);
    
    return hospitalAppointments.map(appointment => {
      const patient = this.users.get(appointment.userId);
      return {
        ...appointment,
        patient: {
          name: patient?.name || 'Unknown',
          email: patient?.email || '',
          phone: patient?.phone || ''
        }
      };
    });
  }
  
  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentCurrentId++;
    const newAppointment: Appointment = {
      ...appointment,
      id,
      status: appointment.status || null,
      clinic: appointment.clinic || null
    };
    this.appointments.set(id, newAppointment);
    
    // Save to persistent storage
    this.saveData();
    
    return newAppointment;
  }
  
  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    
    // Save to persistent storage
    this.saveData();
    
    return updatedAppointment;
  }
  
  // Conversation operations
  async getConversations(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.userId === userId
    );
  }
  
  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }
  
  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const id = this.conversationCurrentId++;
    const now = new Date();
    
    // Properly handle messages - ensure they're an array or null
    let typedMessages: { role: string, content: string }[] | null = null;
    if (Array.isArray(conversation.messages)) {
      typedMessages = conversation.messages.map((msg: any) => ({
        role: typeof msg.role === 'string' ? msg.role : 'user',
        content: typeof msg.content === 'string' ? msg.content : ''
      }));
    }
    
    // Create conversation with properly typed fields
    const newConversation: Conversation = {
      id,
      userId: conversation.userId,
      createdAt: now,
      messages: typedMessages
    };
    this.conversations.set(id, newConversation);
    
    // Save to persistent storage
    this.saveData();
    
    return newConversation;
  }
  
  async updateConversation(id: number, messages: {role: string, content: string}[]): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    
    const updatedConversation = { ...conversation, messages };
    this.conversations.set(id, updatedConversation);
    
    // Save to persistent storage
    this.saveData();
    
    return updatedConversation;
  }
  
  // Create demo data for a new user
  private createDemoDataForUser(userId: number) {
    // Empty implementation to allow user to add their own details
    // No default data will be created
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!email) return undefined;
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getPatientsByHospital(hospitalId: number): Promise<User[]> {
    return await db.select().from(users).where(eq(users.hospitalId, hospitalId));
  }

  async getHospitals(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, 'hospital'));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    
    // Send notifications
    await this.sendRegistrationNotification(user);
    
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async sendEmail(options: { to: string, subject: string, text: string, html: string }): Promise<void> {
    try {
      console.log(`Email would be sent to ${options.to} with subject: ${options.subject}`);
      console.log('Development mode: Skipping actual email send');
    } catch (error) {
      console.log('Error sending email, falling back to console:', error);
    }
  }

  async sendLoginNotification(user: User): Promise<void> {
    if (user.email) {
      await this.sendEmail({
        to: user.email,
        subject: 'Login Notification - Artis Symbiose',
        text: `Hello ${user.name || user.username}, you have successfully logged in to your Artis Symbiose account.`,
        html: `<p>Hello ${user.name || user.username},</p><p>You have successfully logged in to your Artis Symbiose account.</p>`
      });
    }
  }

  async sendRegistrationNotification(user: User): Promise<void> {
    if (user.email) {
      await this.sendEmail({
        to: user.email,
        subject: 'Welcome to Artis Symbiose - Registration Successful',
        text: `Welcome ${user.name || user.username}! Your account has been successfully created.`,
        html: `<p>Welcome ${user.name || user.username}!</p><p>Your account has been successfully created at Artis Symbiose.</p>`
      });
    }
  }

  // Medication operations
  async getMedications(userId: number): Promise<Medication[]> {
    return await db.select().from(medications).where(eq(medications.userId, userId));
  }

  async getMedication(id: number): Promise<Medication | undefined> {
    const [medication] = await db.select().from(medications).where(eq(medications.id, id));
    return medication || undefined;
  }

  async createMedication(medication: InsertMedication): Promise<Medication> {
    const [newMedication] = await db
      .insert(medications)
      .values(medication)
      .returning();
    return newMedication;
  }

  async updateMedication(id: number, medicationData: Partial<Medication>): Promise<Medication | undefined> {
    const [medication] = await db
      .update(medications)
      .set(medicationData)
      .where(eq(medications.id, id))
      .returning();
    return medication || undefined;
  }

  async deleteMedication(id: number): Promise<boolean> {
    const result = await db.delete(medications).where(eq(medications.id, id));
    return result.rowCount > 0;
  }

  // Health metrics operations
  async getHealthMetrics(userId: number): Promise<HealthMetric[]> {
    return await db.select().from(healthMetrics).where(eq(healthMetrics.userId, userId));
  }

  async getHealthMetricsByType(userId: number, type: string): Promise<HealthMetric[]> {
    return await db.select().from(healthMetrics).where(eq(healthMetrics.userId, userId)).where(eq(healthMetrics.type, type));
  }

  async createHealthMetric(metric: InsertHealthMetric): Promise<HealthMetric> {
    const [newMetric] = await db
      .insert(healthMetrics)
      .values(metric)
      .returning();
    return newMetric;
  }

  // Appointment operations
  async getAppointments(userId: number): Promise<Appointment[]> {
    return await db.select().from(appointments).where(eq(appointments.userId, userId));
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db
      .insert(appointments)
      .values(appointment)
      .returning();
    return newAppointment;
  }

  async getHospitalAppointments(hospitalId: number): Promise<any[]> {
    const result = await db
      .select({
        id: appointments.id,
        userId: appointments.userId,
        hospitalId: appointments.hospitalId,
        date: appointments.date,
        time: appointments.time,
        reason: appointments.reason,
        symptoms: appointments.symptoms,
        notes: appointments.notes,
        status: appointments.status,
        createdAt: appointments.createdAt,
        patient: {
          name: users.name,
          email: users.email,
          phone: users.phone
        }
      })
      .from(appointments)
      .leftJoin(users, eq(appointments.userId, users.id))
      .where(eq(appointments.hospitalId, hospitalId));
    
    return result;
  }

  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined> {
    const [appointment] = await db
      .update(appointments)
      .set(appointmentData)
      .where(eq(appointments.id, id))
      .returning();
    return appointment || undefined;
  }

  // Conversation operations
  async getConversations(userId: number): Promise<Conversation[]> {
    return await db.select().from(conversations).where(eq(conversations.userId, userId));
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation || undefined;
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [newConversation] = await db
      .insert(conversations)
      .values(conversation)
      .returning();
    return newConversation;
  }

  async updateConversation(id: number, messages: {role: string, content: string}[]): Promise<Conversation | undefined> {
    const [conversation] = await db
      .update(conversations)
      .set({ messages })
      .where(eq(conversations.id, id))
      .returning();
    return conversation || undefined;
  }
}

export const storage = new DatabaseStorage();
