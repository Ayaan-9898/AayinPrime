# Artis Symbiose - Advanced Ophthalmology Care Platform

## Overview

Artis Symbiose is a comprehensive healthcare management platform focused on ophthalmology care. The system provides medication management, NFC-based implant verification, AI-powered health assistance, and seamless communication between patients and healthcare providers. Built with a modern React frontend and Express.js backend, the platform uses PostgreSQL with Drizzle ORM for data management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state
- **UI Framework**: Radix UI primitives with Tailwind CSS
- **Styling**: Custom design system with CSS variables and Tailwind
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js with local strategy and sessions
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful endpoints with JSON responses

### Database Architecture
- **ORM**: Drizzle with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` for type sharing
- **Migration Strategy**: Drizzle Kit for schema management
- **Connection**: Neon Database (serverless PostgreSQL)

## Key Components

### 1. User Management System
- **Multi-role Architecture**: Patients and hospitals with different access levels
- **Authentication Flow**: Username/password with email verification using OTP
- **Session Handling**: Secure session management with PostgreSQL store
- **Role-based Access**: Different dashboards and features per user type

### 2. Medication Management
- **Digital Medication Tracking**: Schedule management with status tracking
- **NFC Integration**: Scan discharge cards for automatic medication import
- **Prescription Scanner**: Camera-based prescription recognition
- **Status Management**: Track taken/due/upcoming medications

### 3. NFC Implant System
- **Verification Process**: Secure implant verification using NFC technology
- **Hospital Issuance**: Hospitals can issue implant verification numbers
- **Patient Verification**: Patients verify implants using NFC cards
- **Skip Option**: Optional verification for users without implants

### 4. AI Health Assistant
- **Conversational AI**: OpenAI GPT-4o integration for health guidance
- **Context Awareness**: Ophthalmology-focused responses with medical disclaimers
- **Conversation History**: Persistent chat sessions with message history
- **Real-time Chat**: Immediate responses with loading states

### 5. Hospital Management
- **Patient Creation**: Hospitals can create patient accounts
- **License Verification**: Hospital license validation system
- **Medication Editing**: Authorized medication management for patients
- **PIN Security**: Additional security layer for sensitive operations

## Data Flow

### Authentication Flow
1. User selects role (patient/hospital)
2. Provides credentials and role-specific information
3. Email verification with OTP (universal code: "123456" for development)
4. Session creation and role-based dashboard redirect

### Medication Management Flow
1. **NFC Scan**: Read discharge card → Parse medication data → Add to schedule
2. **Prescription Scan**: Camera capture → OCR processing → Manual validation → Add to schedule
3. **Status Updates**: User marks as taken → Update timestamp → Refresh queries

### AI Assistant Flow
1. User sends message → Create/retrieve conversation → Call OpenAI API → Store response → Update UI
2. Conversation persistence across sessions with message history

### Hospital-Patient Interaction
1. Hospital creates patient account → Generate passcode → Send credentials
2. Hospital issues implant number → Patient receives verification ID
3. Hospital edits patient medications → PIN verification → Update patient data

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon Database
- **drizzle-orm**: Database ORM with type safety
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/**: UI component primitives for accessibility
- **openai**: AI assistant integration
- **passport**: Authentication middleware
- **nodemailer**: Email functionality for OTP verification

### Development Tools
- **vite**: Fast build tool with HMR
- **tsx**: TypeScript execution for development
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific integrations

### API Integrations
- **OpenAI GPT-4o**: AI health assistant responses
- **NFC Web API**: Browser-based NFC reading capabilities
- **MediaDevices API**: Camera access for prescription scanning

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` with tsx and Vite HMR
- **Database Sync**: `npm run db:push` for schema updates
- **Type Checking**: `npm run check` for TypeScript validation

### Production Build
- **Frontend Build**: Vite builds React app to `dist/public`
- **Backend Build**: ESBuild bundles server to `dist/index.js`
- **Start Command**: `npm start` runs production server
- **Environment Variables**: Database URL and API keys required

### Database Management
- **Schema Updates**: Drizzle migrations in `./migrations`
- **Connection**: Environment variable `DATABASE_URL` required
- **Session Store**: PostgreSQL-backed session storage

### Security Considerations
- **Password Hashing**: Scrypt-based password hashing with salt
- **Session Security**: Secure session configuration with secrets
- **CORS Configuration**: Proper cross-origin request handling
- **Input Validation**: Zod schema validation for API inputs

## Changelog
- June 28, 2025: Initial setup
- June 28, 2025: Implemented persistent PostgreSQL database storage
  - Added database connection with Neon PostgreSQL
  - Replaced in-memory storage with DatabaseStorage class
  - User login credentials now persist between sessions
  - Fixed CVE-2025-30208 vulnerability by updating Vite
  - All user data, medications, health metrics, appointments, and conversations now stored permanently

## User Preferences

Preferred communication style: Simple, everyday language.