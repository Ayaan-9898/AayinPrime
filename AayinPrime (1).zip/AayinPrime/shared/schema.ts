import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("patient"),
  name: text("name"),
  email: text("email"),
  phone: text("phone"),
  location: text("location"),
  implantVerificationId: text("implant_verification_id"),
  patientHospitalId: integer("patient_hospital_id"),
  implantVerified: boolean("implant_verified").default(false),
  hospitalName: text("hospital_name"),
  hospitalAddress: text("hospital_address"),
  hospitalState: text("hospital_state"),
  licenseId: text("license_id"),
  licenseVerified: boolean("license_verified"),
  implantVerificationNumber: text("implant_verification_number"),
  hospitalId: integer("hospital_id").references(() => users.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
  isVerified: boolean("is_verified").default(false),
  lastLogin: timestamp("last_login"),
  specialty: text("specialty"), // For hospital/doctor users
  profileImageUrl: text("profile_image_url"),
  bio: text("bio"),
  preferences: json("preferences"),
});

export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  time: text("time").notNull(),
  instructions: text("instructions"),
  status: text("status").default("upcoming"),
  expiryDate: timestamp("expiry_date"),
});

export const healthMetrics = pgTable("health_metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  value: text("value").notNull(),
  unit: text("unit"),
  status: text("status"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  hospitalId: integer("hospital_id").notNull(),
  doctorName: text("doctor_name"),
  specialty: text("specialty"),
  clinic: text("clinic"),
  date: timestamp("date").notNull(),
  time: text("time").notNull(),
  reason: text("reason").notNull(),
  symptoms: text("symptoms"),
  notes: text("notes"),
  status: text("status").default("scheduled"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  messages: json("messages").$type<{role: string, content: string}[]>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  name: true,
  email: true,
  phone: true,
  isVerified: true, // For email verification
  specialty: true, // For hospital/doctor users
  location: true,
});

export const insertMedicationSchema = createInsertSchema(medications).pick({
  userId: true,
  name: true,
  dosage: true,
  frequency: true,
  time: true,
  instructions: true,
  status: true,
});

export const insertHealthMetricSchema = createInsertSchema(healthMetrics).pick({
  userId: true,
  type: true,
  value: true,
  unit: true,
  status: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).pick({
  userId: true,
  hospitalId: true,
  doctorName: true,
  specialty: true,
  clinic: true,
  date: true,
  time: true,
  reason: true,
  symptoms: true,
  notes: true,
  status: true,
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  userId: true,
  messages: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type Medication = typeof medications.$inferSelect;

export type InsertHealthMetric = z.infer<typeof insertHealthMetricSchema>;
export type HealthMetric = typeof healthMetrics.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
